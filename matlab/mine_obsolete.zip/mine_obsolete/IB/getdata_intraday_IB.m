
asmp1 = NET.addAssembly(('Q:\My files\Project trading\repo\csharp\IB2\ewrpertest4\bin\release\CSharpAPI.dll'));
asmp2 = NET.addAssembly(('Q:\My files\Project trading\repo\csharp\IB2\ewrpertest4\bin\release\IBBackEnd.dll'));
asmp3 = NET.addAssembly(('Q:\My files\Project trading\repo\csharp\IB2\ewrpertest4\bin\release\IBControlDefinition.dll'));

asm1 = NET.addAssembly('System.IO');
asm2 = NET.addAssembly('System.Runtime.Serialization');

import System.IO.*;
import MHA.*;
import MHA.IBControlDefinition.*;
import MHA.IBControlDefinition.Tools.*;
import MHA.IBControlDefinition.Tools.Contracts.*;
import IBApi.*;

%% constants


        currentTicker = 1;
%         HISTORICAL_ID_BASE = 30000000;
%         ACCOUNT_ID_BASE = 50000000;
%         TICK_ID_BASE = 10000000;
%         ACCOUNT_SUMMARY_ID = ACCOUNT_ID_BASE + 1;
%         ACCOUNT_SUMMARY_TAGS = "AccountType,NetLiquidation,TotalCashValue,SettledCash,AccruedCash,BuyingPower,EquityWithLoanValue,PreviousEquityWithLoanValue,GrossPositionValue,ReqTEquity,ReqTMargin,SMA,InitMarginReq,MaintMarginReq,AvailableFunds,ExcessLiquidity,Cushion,FullInitMarginReq,FullMaintMarginReq,FullAvailableFunds,FullExcessLiquidity,LookAheadNextChange,LookAheadInitMarginReq ,LookAheadMaintMarginReq,LookAheadAvailableFunds,LookAheadExcessLiquidity,HighestSeverity,DayTradesRemaining,Leverage";
% 





%% init

signal=EReaderMonitorSignal;
ibClient=IBClient(signal);
ibWrapper=IBWrapper(ibClient,signal);

%% set handles

%all standard handles are available to signal matlab as well

eventhandlerError= addlistener(ibWrapper,'HandledError',@HandledErrorFcn);

eventhandlerTick = addlistener(ibWrapper,'HandledTick',@HandledTickFcn);
eventhandlerOrderStatus = addlistener(ibWrapper,'HandledOrderStatus',@HandledOrderStatusFcn);
eventhandlerPositions= addlistener(ibWrapper,'HandledPosition',@HandledPositionFcn);

eventhandlerHistoricalDataUpdate= addlistener(ibWrapper,'HandledHistoricalDataUpdate',@HandledHistoricalDataUpdateFcn);
eventhandlerHistoricalData= addlistener(ibWrapper,'HandledHistoricalData',@HandledHistoricalDataFcn);
eventhandlerHistoricalEndData= addlistener(ibWrapper,'HandledHistoricalDataEnd',@HandledHistoricalDataEndFcn);


 
 %% connect
 
  if (ibClient.ClientSocket.IsConnected()  ==0)
ibClient.ClientId=5;
ibWrapper.Connect('', 7497, ibClient.ClientId);
  end
isconnected=ibClient.ClientSocket.IsConnected();        

if (isconnected)

 ibClient.ClientSocket.reqMarketDataType(3); %1 for realtime 2 frozen, 5 delayd frozen, 3 delayed
pause(1);

  %% setup
symbols_ib;
 % symbols={'AAPL'};
   duration = "1 D"; % //S,D,W,M,Y
             barsize = "1 min";
         
                 keepuptodate = false;
                 whattoshow="TRADES";
     RTHonly=1; % during market time
  
year_=2020;
for months_=1:4
for days_=1:31
date0=[num2str(year_) '-' num2str(months_,'%02.f') '-' num2str(days_,'%02.f')]
dateib=[num2str(year_) num2str(months_,'%02.f') num2str(days_,'%02.f')];
enddatetime = [dateib ' 22:00:00']; %//empty for most recent when keepuptodate=true... sample 20200615 13:22:00, if goal is to get only historical data, then use end of day time, and keepuptodate=false

    
for si=1:numel(symbols)
symbol=symbols{si}
contract=  genContract([],symbol);     

filename=['Z:\My files\Project trading\traderdata\data\IB\' filefriendlysymbol(contract.FileSymbol) ' minute ' date0 '.mat'];

if (~exist(filename))
    
%% get historical data

%and put it in some timetable
 tm=genNanTimeTable(datetime([date0 ' 09:30:00'])+minutes((0:389)'));

 if (ibClient.ClientSocket.IsConnected()  ==0)
ibWrapper.Connect('', 7497, ibClient.ClientId);
 end
if (ibClient.ClientSocket.IsConnected()==1)
 ibClient.ClientSocket.reqMarketDataType(3); %1 for realtime 2 frozen, 5 delayd frozen, 3 delayed
pause(1);
    
disp('requesting data...');
ibWrapper.CleanUpHistoricalData(); 
ibWrapper.CleanUpHistoricalDataEnd(); % CleanUpHistoricalDataEnd instead, dll was not developed yet at the time
  
   timetablename{currentTicker}='tm';
            reqid = ibWrapper.HISTORICAL_ID_BASE + currentTicker;
            currentTicker=currentTicker+1;
            
                
            ibWrapper.reqHistoricalData(reqid, contract, enddatetime, duration, barsize,whattoshow , 0, 1, keepuptodate, NET.createArray('IBApi.TagValue',0));
    
waitUnlessError(ibWrapper);
disp('grabbed all');

% IB misses data , so do it two times

disp('Correcting missing data...');
ibWrapper.CleanUpHistoricalData(); 
ibWrapper.CleanUpHistoricalDataEnd(); % CleanUpHistoricalDataEnd instead, dll was not developed yet at the time

            reqid = ibWrapper.HISTORICAL_ID_BASE + currentTicker;
            currentTicker=currentTicker+1;
            ibWrapper.reqHistoricalData(reqid, contract, enddatetime, duration, barsize,whattoshow , RTHonly, 1, keepuptodate, NET.createArray('IBApi.TagValue',0));
    
waitUnlessError(ibWrapper);
disp('grabbed all');

 
 save(filename,'tm');

 pause(5);
end
end
end
end
end

%% disconnect  
                  
ibWrapper.Disconnect();
else
    disp('did not connect');
end

  
ibClient.ClientSocket.IsConnected()
  
    
     