%% init dates

%collect 1min data every weekend before they become unavailable
dtnow=datetime();
if (hour(dtnow)>=16)
 lastfullday=(day(dtnow));
else 
lastfullday=(day(dtnow)-(1));
end
days_=31:-1:1;%lastfullday:-1:1;
cmonth=month(dtnow);

if (cmonth==1)
   months_=1; %doesn't really matter.. the data must have been taken before
else
  months_=cmonth:-1:(cmonth-2);
end

year_=year(dtnow);


%% loop through contracts

contracts_yahoo;
s1=contracts;
contracts_tda;
s2=contracts;

allcontracts=unique([s1,s2]);

%allcontracts={genContract('AAL')};
ns=numel(allcontracts);
for si=1:ns

    try
    
    contract=allcontracts(si);
   % symbol=symbol{1}
    
%% init volumeproifle
minutesIndex=(1:390)';

DataCount=zeros(size(minutesIndex));
Open=DataCount;
High=DataCount;
Low=DataCount;
Close=DataCount;
Volume=DataCount;
temppap=table(minutesIndex,Open,High,Low,Close,Volume);
DataCountW={DataCount,DataCount,DataCount,DataCount,DataCount};
PriceActionProfileW={temppap,temppap,temppap,temppap,temppap};
    
%% loop through dates

for j=months_
for i=days_
    try
   date_=[num2str(year_) '-' num2str(j,'%02.f') '-' num2str(i,'%02.f')];
wd=weekday(date_)-1;
minutedatafilename=['Z:\My files\Project trading\traderdata\data\' filefriendlysymbol(contract.FileSymbol) ' minute ' date_ '.mat'];
if (exist(minutedatafilename))
load(minutedatafilename);

if (~isempty(tm))

dt=datetime(tm.Date);
minutesIndex=minutes(dt-dt(1))+1;
Volume=tm.Volume;
Open=tm.Open;
Close=tm.Close;
Low=tm.Close;
High=tm.High;

cum1=ones(size(minutesIndex));
cum1(isnan(Volume) | isnan(Open) | isnan(Close))=0;

DataCountW{wd}(minutesIndex)=DataCountW{wd}(minutesIndex)+cum1;

Volume(cum1==0)=0;
Open(cum1==0)=0;
Close(cum1==0)=0;
Low(cum1==0)=0;
High(cum1==0)=0;

PriceActionProfileW{wd}(minutesIndex,:).Volume=PriceActionProfileW{wd}(minutesIndex,:).Volume+Volume;
PriceActionProfileW{wd}(minutesIndex,:).Open=PriceActionProfileW{wd}(minutesIndex,:).Open+Open;
PriceActionProfileW{wd}(minutesIndex,:).Close=PriceActionProfileW{wd}(minutesIndex,:).Close+Close;
PriceActionProfileW{wd}(minutesIndex,:).Low=PriceActionProfileW{wd}(minutesIndex,:).Low+Low;
PriceActionProfileW{wd}(minutesIndex,:).High=PriceActionProfileW{wd}(minutesIndex,:).High+High;

end
end

    catch
    end
    
end
end

for wd=1:5
PriceActionProfileW{wd}.Volume=PriceActionProfileW{wd}.Volume./DataCountW{wd};
PriceActionProfileW{wd}.Open=PriceActionProfileW{wd}.Open./DataCountW{wd};
PriceActionProfileW{wd}.Close=PriceActionProfileW{wd}.Close./DataCountW{wd};
PriceActionProfileW{wd}.Low=PriceActionProfileW{wd}.Low./DataCountW{wd};
PriceActionProfileW{wd}.High=PriceActionProfileW{wd}.High./DataCountW{wd};
end

vfilename=['Z:\My files\Project trading\traderdata\data_processed\priceactionprofile\' filefriendlysymbol(contract.FileSymbol) ' priceactionprofilew.mat'];
save(vfilename,'PriceActionProfileW');

    catch exception
     getReport(exception,'extended','hyperlinks','off') 
    
end

end


date0='2020-06-01';
wd=weekday(date0);

PriceActionProfileW{wd}.Date=datetime([date0 ' 09:30:00'])+minutes((0:389)');

cndl5(PriceActionProfileW{wd});

min_=min(PriceActionProfileW{wd}.Low);
max_=max(PriceActionProfileW{wd}.High);

ylim([min_ max_]);
