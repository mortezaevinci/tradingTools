function PredictionTable=upper_indicators_ideal(StockData_TimeTable)
zero=zeros(size(StockData_TimeTable.Close));
try
%Moving Average 3th - 6th Features
sma5=movavg(StockData_TimeTable.Close,'linear',5);
sma5(isnan(sma5))=StockData_TimeTable.Open(1);
catch
    sma5=zero;
end
try
sma10 = movavg(StockData_TimeTable.Close,'linear',10);
sma10(isnan(sma10))=StockData_TimeTable.Open(1);
catch
    sma10=zero;
end
try
sma21 = movavg(StockData_TimeTable.Close,'linear',21);
sma21(isnan(sma21))=StockData_TimeTable.Open(1);
catch
    sma21=zero;
end
try
sma50 = movavg(StockData_TimeTable.Close,'linear',50);
sma50(isnan(sma50))=StockData_TimeTable.Open(1);
catch
    sma50=zero;
end

nsma5=normalizeQuote(sma5);
nsma10=normalizeQuote(sma10);
nsma21=normalizeQuote(sma21);
nsma50=normalizeQuote(sma50);



try
%Exponential Moving Average 7 Feature
EMA7 = movavg(StockData_TimeTable.Close,'exponential',7);
catch
    EMA7=zero;
end
try

%Time Series Bollinger band 13-15 Features
[middle,upper,lower] = bollinger(StockData_TimeTable,'WindowSize',20);
catch
    middle.Open=zero;
    upper.Open=zero;
    lower.Open=zero;
end
try

%Highest high 16 Features
highind = hhigh(StockData_TimeTable) ;
catch
    highind.HighestHigh=zero;
end
try
%Lowest low 17 Features
lowind = llow(StockData_TimeTable);
catch
    lowind.LowestLow=zero;
end
try
%Median Price 18 Features
MedIdx = medprice(StockData_TimeTable);
catch
    MedIdx.MedianPrice=zero;
end
try
%williams Accumulation/Distribution line 21 Features
willadidx = willad(StockData_TimeTable);
catch
    willadidx.WillAD=zero;
end

varnames={'sma5','sma10','sma21','sma50',...
    'nsma5','nsma10','nsma21','nsma50',...
    'EMA7',...
    'BBmiddle','BBupper','BBlower','HighestHigh',...
    'LowestLow','MedianIndex',...
    'WillAD'};

%As explained, price today will be used to predict the stock price tomorrow. Hence all the indicators move forward 1 date.
% Only Open price of stock will be considered as feature as it is the only price we know before opening market in the day.
% 1st data point will be removed as there does not have any value for their feature indicators.
PredictionTable = timetable(StockData_TimeTable.Date, ...
    sma5, sma10, sma21,sma50,...
    nsma5, nsma10, nsma21, nsma50,...
    EMA7,...
    middle.Open, upper.Open, lower.Open, highind.HighestHigh,...
    lowind.LowestLow, MedIdx.MedianPrice ,willadidx.WillAD,'VariableNames',varnames);

end