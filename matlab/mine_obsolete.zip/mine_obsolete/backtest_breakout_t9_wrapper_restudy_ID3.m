%for now, this would only work for the last day of data, because of the way
%last day and last month are found.

%************this will probably not work at the first day of the month...
%need to find the last month, last day better.. maybe won't even work at
%the beginnign of thre day

%can possibly update tm data in real-time here, and show

close all

 global SYMBOLDONETODAY;
clearvars -except SYMBOLDONETODAY parf;

%looperparams_realtime;
%run('config\looperparams_backtestall.m');
run('config\looperparams_realtime_t9_restudy_ID3');


%run('config\looperparams_realtime_study_extended.m');

%run('config\commonticks_patternrec_t9_ID4.m');
run('config\commonticks_patternrec_t9_ID3.m');

%%bypass
 
looperEngine.contracts={genContract([],'MSFT'),genContract([],'AMZN')};
%looperEngine.symbols={genContract([],'INO'),genContract([],'MGM'),genContract([],'WFC')};

%main params
%run('config\mainparams_backtest_test_t7_STUDY.m');
run('config\mainparams_backtest_test_t9_STUDY_ID3.m');
%% prepare

backtest_breakout_t9_prepare;

%% background workers
if (looperEngine.updaterealtime==1 || looperEngine.getalldatainrealtime==1)
    backtest_breakout_t7_workeron;
end

contracts_=looperEngine.contracts;

symbolsections=[1:16:numel(contracts_)];
if (symbolsections(end)~=numel(contracts_)+1)
	symbolsections=[symbolsections numel(contracts_)+1];
end

for symbi=1:(numel(symbolsections)-1)
    close all
looperEngine.contracts=contracts_(symbolsections(symbi):(symbolsections(symbi+1)-1));
backtest_breakout_t9;



%pause;
end

looperEngine.contracts=contracts_;

backtest_evaluate_t9;

try
 backtest_breakout_t7_workeroff;
catch
    
end