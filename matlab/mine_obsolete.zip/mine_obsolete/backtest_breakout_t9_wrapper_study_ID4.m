%for now, this would only work for the last day of data, because of the way
%last day and last month are found.

%************this will probably not work at the first day of the month...
%need to find the last month, last day better.. maybe won't even work at
%the beginnign of thre day

%can possibly update tm data in real-time here, and show

close all

 global SYMBOLDONETODAY;
clearvars -except SYMBOLDONETODAY parf;

%looperparams_realtime;
%run('config\looperparams_backtestall.m');
run('config\looperparams_realtime_study_ID4');

%run('config\looperparams_realtime_study_extended.m');

run('config\commonticks_patternrec_t9_ID4.m');

%%bypass
 
%looperEngine.contracts={genContract([],'AAPL')};
%main params
%run('config\mainparams_backtest_test_t7_STUDY.m');
run('config\mainparams_backtest_test_t9_STUDY_ID4.m');
%run('config\mainparams_backtest_test_t7_loose.m');
%% prepare

backtest_breakout_t9_prepare;

%% background workers
if (looperEngine.updaterealtime==1 || looperEngine.getalldatainrealtime==1)
    backtest_breakout_t7_workeron;
end

contracts_=looperEngine.contracts;

symbolsections=[1:16:numel(contracts_)];
if (symbolsections(end)~=numel(contracts_)+1)
	symbolsections=[symbolsections numel(contracts_)+1];
end

for symbi=1:(numel(symbolsections)-1)
    close all
looperEngine.contracts=contracts_(symbolsections(symbi):(symbolsections(symbi+1)-1));
backtest_breakout_t9;



pause;
end

disp('conditoions performance matrix:');
nperf=numel(performancematrix);

pmean=zeros(size(performancematrix{1}));
for i=1:nperf
    pmean=pmean+performancematrix{i};
    
end
pmean=pmean/nperf;
 dispPerformanceMatrix(mainticks{1}.debug,pmean);

disp('indicators average performance matrix');
nperf=numel(performanceMatrix.indicatorsAverage);
pmean=zeros(size(performanceMatrix.indicatorsAverage{1}));
for i=1:nperf
    pmean=pmean+performanceMatrix.indicatorsAverage{i};
    
end
pmean=pmean/nperf;

 dispPerformanceMatrix_indicatorsAverage(mainticks{1}.calculations,pmean);
%  
% indicatorsProfile.mean=(pmean(1,:)+pmean(2,:))/2;
% indicatorsProfile.range=1./((pmean(1,:)-pmean(2,:))/2);



try
 backtest_breakout_t7_workeroff;
catch
    
end