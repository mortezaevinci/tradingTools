
    mainticks{si}.params=strategy_getdata(looperParams,mainticks{si}.params);


%% evaluate symbols

%% loop


%parfor  (si=1:nsymbols,useparfor)

 

%% update real-time could be lower, if orb level was done a bit differently
[mainticks{si}.calculations,mainticks{si}.debug]=strategy_breakout_t8(looperParams,mainticks{si}.params,commonticks);

[X,T,t,indices,viewx]=generateNetInputs(looperParams,mainticks{si}.params,mainticks{si}.calculations,commonticks);



