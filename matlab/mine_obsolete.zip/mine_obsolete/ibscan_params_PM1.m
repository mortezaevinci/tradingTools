% lastVsEMAChangeRatio20Above
% 50
% 100
% 200
% 
% curMACDAbove
% curMACDSignalAbove
% curMACDDistAbove
% replace MACD with PPO
% 
% shortInterestChgAbove
% 
% shortOutstandingRatioAbove
% 
% market_edgeAbove
% 
% market_graderAbove
% 
% not changed much last day, but suddenly changed at premarket:
% 
% changePercAbove 5
% changePercBelow 15
% curMACDBelow 0
% lastVsEMAChangeRatio20Below 0
% lastVsEMAChangeRatio50Above 0
% lastVsEMAChangeRatio100Above 0
% lastVsEMAChangeRatio200Above 0


%parameters
ibscansize=50;
clear tv;
    tv{1} = IBApi.TagValue("marketCapAbove1e6", "20");
    tv{2} = IBApi.TagValue("volumeAbove", "50000");
    tv{3} = IBApi.TagValue("priceAbove", "0.8");
    tv{3} = IBApi.TagValue("priceBelow", "25");
    tv{4} = IBApi.TagValue("changePercAbove", "1");
     tv{5} = IBApi.TagValue("changePercBelow", "10");
     tv{6} = IBApi.TagValue("lastVsEMAChangeRatio20Above", "0");
     %tv{7} = IBApi.TagValue("lastVsEMAChangeRatio50Above", "0");
     %tv{8} = IBApi.TagValue("lastVsEMAChangeRatio100Above", "0");
     %tv{9} = IBApi.TagValue("lastVsEMAChangeRatio200Above", "0");
    
    tvs = NET.createGeneric('System.Collections.Generic.List',{'IBApi.TagValue'},numel(tv));
    for i=1:numel(tv)
    tvs.Add(tv{i});
    end
    
 tvsscanner=NET.createGeneric('System.Collections.Generic.List',{'IBApi.TagValue'},0);
            
 subscription = IBApi.ScannerSubscription;
 subscription.ScanCode = 'ALL_SYMBOLS_ASC';
 subscription.Instrument = 'STK';
 subscription.LocationCode = 'STK.US.MAJOR';
 subscription.StockTypeFilter = 'ALL';
 subscription.NumberOfRows = ibscansize;    
