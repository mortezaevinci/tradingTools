%for now, this would only work for the last day of data, because of the way
%last day and last month are found.

%************this will probably not work at the first day of the month...
%need to find the last month, last day better.. maybe won't even work at
%the beginnign of thre day

%can possibly update tm data in real-time here, and show

close all

 global SYMBOLDONETODAY;
clearvars -except SYMBOLDONETODAY parf;

%looperparams_realtime;
%run('config\looperparams_backtestall.m');
run('config\looperparams_realtime_t9_ID3');

%run('config\looperparams_realtime_study_extended.m');

%run('config\commonticks_patternrec_t9_ID4.m');
run('config\commonticks_patternrec_t9_ID3.m');

%%bypass
 
%looperEngine.contracts={genContract([],'BA'),genContract([],'SPY')};
%main params
%run('config\mainparams_backtest_test_t7_STUDY.m');
run('config\mainparams_backtest_test_t9_STUDY_ID3.m');

%% prepare

backtest_breakout_t9_prepare;

%% background workers

% if (looperEngine.updaterealtime==1 && looperEngine.IB.run==1)
%     ib_realtime_t10_workeron;
% end

if (looperEngine.updaterealtime==1 || looperEngine.getalldatainrealtime==1)
    backtest_breakout_t7_workeron;
end

%% divide to sections if more than 16 mainticks

contracts_=looperEngine.contracts;
contracts_sections=[1:16:numel(contracts_)];
if (contracts_sections(end)~=numel(contracts_)+1)
	contracts_sections=[contracts_sections numel(contracts_)+1];
end

%% main loop

for coni=1:(numel(contracts_sections)-1)
    close all
looperEngine.contracts=contracts_(contracts_sections(coni):(contracts_sections(coni+1)-1));
backtest_breakout_t9;
ib_engine_cancel_disconnect;

pause;
end

%% other evaluation

try
disp('conditoions performance matrix:');
nperf=numel(performancematrix);

pmean=zeros(size(performancematrix{1}));
for i=1:nperf
    pmean=pmean+performancematrix{i};
    
end
pmean=pmean/nperf;
 dispPerformanceMatrix(mainticks{1}.debug,pmean);

disp('indicators average performance matrix');
nperf=numel(performanceMatrix.indicatorsAverage);
pmean=zeros(size(performanceMatrix.indicatorsAverage{1}));
for i=1:nperf
    pmean=pmean+performanceMatrix.indicatorsAverage{i};
    
end
pmean=pmean/nperf;

 dispPerformanceMatrix_indicatorsAverage(mainticks{1}.calculations,pmean);

catch
    
end

%% background workers off

try
 backtest_breakout_t7_workeroff;
 %ib_realtime_t10_workeroff;

catch
    
end