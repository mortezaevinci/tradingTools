%for now, this would only work for the last day of data, because of the way
%last day and last month are found.

%************this will probably not work at the first day of the month...
%need to find the last month, last day better.. maybe won't even work at
%the beginnign of thre day

%can possibly update tm data in real-time here, and show

try

%% prepare 
%tic
somethingtodo=datetime('2019-01-01');
 ncommon=numel(commonticks);
ncontracts=numel(looperEngine.contracts);

 global PRESSEDKEY;
PRESSEDKEY = 0;

WarnWave = [sin(1:.3:300), sin(1:.5:300)];%, sin(1:.4:300)];
Audio = audioplayer(WarnWave, 44100);
if (looperEngine.graph.show>0)
   
if (looperEngine.graph.isfull)
for si=1:ncontracts
bbFig{si}=figure('units','normalized','outerposition',looperEngine.graph.figureSize);
panel{si}=uipanel('Title',looperEngine.contracts{si}.Symbol,'Position',[0 0 1 1]);
set(bbFig{si}, 'WindowKeyPressFcn', @myKeyPressFcn)
end
else
bbFig{1}=figure('units','normalized','outerposition',looperEngine.graph.figureSize);
set(bbFig{1}, 'WindowKeyPressFcn', @myKeyPressFcn)

%bbFigspecial=figure('units','normalized','outerposition',looperEngine.graph.figureSize);
%panelspecial=uipanel('Title','Selected','Position',[0 0 1 1]);
%set(bbFigspecial, 'WindowKeyPressFcn', @myKeyPressFcn);
end

end
PRESSEDKEY = 0;

sir=min(2,ncontracts);
sis=ceil(ncontracts/sir);
w=1;
h=1;

crumb=[];
rq=[];


for si=1:ncontracts
    mainticks{si}.params=loadprofile_PMATP1(mainticks{si}.params,looperEngine);
    mainticks{si}.params=loadprofile_PAPP1(mainticks{si}.params,looperEngine);
end

for si=1:ncommon
    commonticks{si}.params=loadprofile_PMATP1(commonticks{si}.params,looperEngine);
    commonticks{si}.params=loadprofile_PAPP1(commonticks{si}.params,looperEngine);
end

%parpool('local');


for si=1:ncontracts   
    lastclose{si}=-1;
     lastshowlimit{si}=-1;
     lastdatasize{si}=-1;
    sc=floor((si-1)/sir);
    sr=(si-1)-sc*sir;
    sr=-si+(sc+1)*sir;
    if (looperEngine.graph.isfull)
        
    else
        if (looperEngine.graph.show>0)
           panelPosition{si}=[w*sc/sis h*sr/sir w*1/sis h/sir];
           panel{si}=uipanel('Title',[looperEngine.contracts{si}.FileSymbol '(' (char('a'+si-1)) ')'],'Position',panelPosition{si});
        end
    end
end

threadPlot_single = parallel.pool.DataQueue;
threadPlot_single.afterEach(@(x) graphStrategy_full_t9(x{2}.layout,x{2},x{3},x{4},x(5))); 
threadPlot = parallel.pool.DataQueue;
threadPlot.afterEach(@(x) graphStrategy_t9(x{2}.layout,x{2},x{3},x{4},x(5)));

%ticprepare=toc;
%tic
%pause(2); %graphs need to init first

%init graph
disp('initializing...');
for  si=1:ncontracts
disp(mainticks{si}.params.contract.Symbol);

 
if (looperEngine.net.use==1)
    mainticks{si}.params.net.use=1;
    
    netfilename=['Z:\My files\Project trading\traderdata\nets\netP1 ' filefriendlysymbol(mainticks{si}.params.contract.FileSymbol) ' ID' num2str(looperEngine.net.setupId) '.mat'];
    if (exist(netfilename))
        load(netfilename);
        mainticks{si}.params.net.netP1=netP1;  
    end
end

if (looperEngine.graph.show==2 || (looperEngine.graph.show==1))
%graphStrategy_t2(bbFig,panel{si},mainticks{si}.params,calculations,result);

% if (numel(PRESSEDKEY)==1 && PRESSEDKEY==('a'+si-1) && ~looperEngine.runOnce)
%    % graphStrategy_full_t5(panelspecial,mainticks{si}.params,mainticks{si}.calculations,result{si});
% else
if (looperEngine.graph.isfull)
mainticks{si}.params.layout=graphStrategy_full_t9_init(panel{si},looperEngine,mainticks{si}.params,mainticks{si}.result);

else
mainticks{si}.params.layout=graphStrategy_t10_init(panel{si},looperEngine,mainticks{si}.params,mainticks{si}.result);

end
%end
end
end

%ticinitgraphs=toc


disp('ready to go...');
if (looperEngine.continueAfterInit==0)
pause;
end

%tic
global initgetdatadone;
%parfeval(@initGetdata_t8,3,looperEngine,params,commonticks);
[sucess,mainticks,commonticks]=initGetdata_t8(looperEngine,mainticks,commonticks);
    
selectedchannel='z';
selectedchannelupdated=1;

%% first ib engine

ib_engine(mainticks,commonticks,looperEngine);

%% keep loop

while(initgetdatadone==0)
pause(.5);
end

%ticinitdata=toc

disp('Go!');

%% evaluate symbols
lastalert=datetime();

looperEngine.backupShowLimit=looperEngine.graph.showlimit;

while(1)

try
%tic
    ib_engine(mainticks,commonticks,looperEngine); 
    %ticibengine=toc


    if (~isempty(PRESSEDKEY))
    if (PRESSEDKEY(1)=='0')
        break;
    end
    end
    
%% loop

 %% evaluate commonticks
 %tic

    for si2=1:ncommon
        try
        if (looperEngine.updaterealtime==1)
       % commonticks{si2}.params=updaterealtimeByRealTimeBars(commonticks{si2}.params);
        commonticks{si2}.params=updaterealtimeByFile(commonticks{si2}.params);
          commonticks{si2}.params=updaterealtimeByHistoricalDataUpdate(commonticks{si2}.params);
        else
        commonticks{si2}.params=strategy_getdata(looperEngine,commonticks{si2}.params);
        end

        
        commonticks{si2}.calculations=strategy_breakout_t10(looperEngine,commonticks{si2}.params,[]);
        catch exception
   getReport(exception,'extended','hyperlinks','on') 
    
end
    end
 %ticbcommon=toc


for si=1:ncontracts
    try
    if (~isempty(PRESSEDKEY))
    if (PRESSEDKEY(1)=='0')
        break;
    end
    end

    


if (~isempty(PRESSEDKEY))
   if (strcmp(PRESSEDKEY,'leftarrow'))
       PRESSEDKEY='';
       looperEngine.graph.showlimit=looperEngine.graph.showlimit+looperEngine.graph.showlimitstep;
       if (looperEngine.graph.showlimit>looperEngine.graph.showlimitmax)
           looperEngine.graph.showlimit=looperEngine.graph.showlimitmax;
       end
   end
   
   if (strcmp(PRESSEDKEY,'rightarrow'))
       PRESSEDKEY='';
       looperEngine.graph.showlimit=looperEngine.graph.showlimit-looperEngine.graph.showlimitstep;
       if (looperEngine.graph.showlimit<0)
           looperEngine.graph.showlimit=0;
       end
   end
end


%% update real-time could be lower, if orb level was done a bit differently
%tic
if (looperEngine.updaterealtime==1 && looperEngine.backStudyPoints==0)
    %mainticks{si}.params=updaterealtimeByRealTimeBars(mainticks{si}.params);
    
    mainticks{si}.params=updaterealtimeByFile(mainticks{si}.params);
    mainticks{si}.params=updaterealtimeByHistoricalDataUpdate(mainticks{si}.params);
else
    mainticks{si}.params=strategy_getdata(looperEngine,mainticks{si}.params);
end

    
if (looperEngine.backStudyPoints>0)
   mainticks{si}.params.TimeTables.Minute=mainticks{si}.params.TimeTables.Minute(1:(390-looperEngine.backStudyPoints),:); 
end
%ticbupdatedata=toc

%tic    
if (numel(PRESSEDKEY)==1 && PRESSEDKEY>='a' && PRESSEDKEY<'a'+ncontracts)
    selectedchannel=PRESSEDKEY;
    PRESSEDKEY='';
    selectedchannelupdated=0;
end
if (numel(PRESSEDKEY)==1 && PRESSEDKEY=='z')
    selectedchannel='z';
    PRESSEDKEY='';
    selectedchannelupdated=0;
end

if (selectedchannel=='z' && selectedchannelupdated==0)

   %show all again
   for jj=1:ncontracts
       panel{jj}.Position=panelPosition{jj};
      panel{jj}.Visible=true; 
      mainticks{jj}.params.layout.extended=0;
   end
   selectedchannelupdated=1;
end

% one symbol is selected
if (selectedchannel=='a'+si-1  && selectedchannelupdated==0)
    for jj=1:ncontracts
     
      panel{jj}.Visible=false; 
    end
   selectedsi=selectedchannel-'a'+1;
   
   panel{selectedsi}.Position=[0 0 1 1];
   panel{selectedsi}.Visible=true;
   mainticks{selectedsi}.params.layout.extended=1;
   
      selectedchannelupdated=1;
end

if (selectedchannel~='a'+si-1  && selectedchannel~='z')
   continue; 
end

%ticmanagechannels=toc

disp(mainticks{si}.params.contract.Symbol);

try %in case no data was available
% don't do anything if, there is no new data
newdatasize=numel(mainticks{si}.params.TimeTables.Minute.Date);
newlastclose=mainticks{si}.params.TimeTables.Minute.Close(end);

if ((newlastclose==lastclose{si} && newdatasize==lastdatasize{si}) && lastshowlimit{si}==looperEngine.graph.showlimit)
    drawnow;
    continue;
else
    lastshowlimit{si}=looperEngine.graph.showlimit;
    lastclose{si}=newlastclose;
    lastdatasize{si}=newdatasize;
end
catch
    
end

disp('Processing...');

try
%tic
 %;disp('calculations');
if (mainticks{si}.params.doBookOnly==0)
    
if (looperEngine.useBookLevels>0)
datestring=datestr(datetime(looperEngine.date),'yyyy-mm-dd');
filename=['Z:\My files\Project trading\traderdata\book\' filefriendlysymbol(mainticks{si}.params.contract.Symbol) '_book_history ' datestring '.bn2'];
mainticks{si}.params.marketdata=getProcessedMarketdata2(filename,datestring);
if (~isempty(mainticks{si}.params.marketdata))
mainticks{si}.params.marketdata=marketbooklevels(mainticks{si}.params.marketdata);
end
end

[mainticks{si}.calculations,mainticks{si}.debug]=strategy_breakout_t10(looperEngine,mainticks{si}.params,commonticks);

if (mainticks{si}.calculations.started==0 && looperEngine.updaterealtime==1)
    disp('pausing 1 sec');
    pause(1); %just to give room to UI to interact when there is no data
end
%ticbooksAndStrategy=toc
%tic
%calculations=fetchOutputs(parf);
 %;disp('results');
mainticks{si}.result=signals_next5_t1(mainticks{si}.params,mainticks{si}.calculations);

%% results
somethingtodo=alertSignals(mainticks{si}.params,mainticks{si}.calculations);
end

catch exception
   getReport(exception,'extended','hyperlinks','on') 
end

%ticbcalcsandres=toc
%tic
somealertchanged=seconds(datetime()-somethingtodo)<60 && (seconds(datetime()-lastalert))>30;
try

if (somealertchanged)
play(Audio); 
lastalert=datetime();
end
%ticalert=toc

catch exception
   getReport(exception,'extended','hyperlinks','on') 
end

try
%tic
 %;disp('graph');
if (looperEngine.graph.show==2 || (looperEngine.graph.show==1 && somealertchanged))
%graphStrategy_t2(bbFig,panel{si},mainticks{si}.params,calculations,mainticks{si}.result);


if (looperEngine.graph.isfull)

%send(threadPlot_single,{si,mainticks{si}.params,mainticks{si}.calculations,mainticks{si}.result);
graphStrategy_full_t9(mainticks{si}.params.layout,looperEngine,mainticks{si}.params,mainticks{si}.calculations,mainticks{si}.result);
else
%send(threadPlot,{si,mainticks{si}.params,mainticks{si}.calculations,result{si}});
graphStrategy_t10(mainticks{si}.params.layout,looperEngine,mainticks{si}.params,mainticks{si}.calculations,mainticks{si}.result);
end


%drawnow;
%ticbgraph=toc
end

catch exception
   getReport(exception,'extended','hyperlinks','on') 
end

catch exception
   getReport(exception,'extended','hyperlinks','on') 
end

end

%tic
if (looperEngine.graph.saveFigures)
    disp('saving figures...');
    nfig=numel(bbFig);
    for i=1:nfig
        if (nfig==numel(looperEngine.contracts))
            symname=looperEngine.contracts{i}.FileSymbol;
        else
          symname='';
          for i=1:numel(looperEngine.contracts)
            symname=[symname looperEngine.contracts{i}.FileName '_'];
          end
        end
       
       saveas(bbFig{i},['Z:\My files\Project trading\traderdata\figures\fig_' filefriendlysymbol(symname) datestr(datetime(),"yy-mm-dd hh_MM_ss") '.svg']);
       savefig(bbFig{i},['Z:\My files\Project trading\traderdata\figures\fig_' filefriendlysymbol(symname) datestr(datetime(),"yy-mm-dd hh_MM_ss") '.fig']);
    end
end
%ticsavefig=toc

if (looperEngine.runOnce==1) 
    break;
end

if (looperEngine.backStudyPoints>0)
    
    cntup=1;
        if (~isempty(PRESSEDKEY))
    if (PRESSEDKEY(1)>'0' && PRESSEDKEY(1)<='9')
       cntup=PRESSEDKEY(1)-'0';
    end
    end
    
looperEngine.backStudyPoints=looperEngine.backStudyPoints-cntup;
if (looperEngine.backStudyPoints<=0)
    break;
end
pause(1);
end

catch exception
   getReport(exception,'extended','hyperlinks','on') 
    
end



end %while



catch exception
   getReport(exception,'extended','hyperlinks','on') 
    
end