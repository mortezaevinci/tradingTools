function [calculations,debug]=strategy_breakout_t8(looperParams,params,commonticks)

debug=[];
try
calculations.started=1;

global showbackdateonce;
if (looperParams.processType==0)
timetablePrimary=params.TimeTables.Minute;
timetableSecondary=params.TimeTables.Day;
timetableAuxilary=params.TimeTables.Month;
alpha=.75;
alphalong=0.75;
end
if (looperParams.processType==1)
timetablePrimary=params.TimeTables.Day(end-90:end,:);
timetableSecondary=params.TimeTables.Day;
timetableAuxilary=params.TimeTables.Month;
alpha=0.25;
alphalong=0.75;
end

%% preperation
try
    themorningdate=datetime([datestr(timetablePrimary.Date(end),'yyyy-mm-dd') ' 09:30:00']);

    
%;tic
% for monthly pivots
tr=timerange(themorningdate- day(themorningdate)-day(28)-day(10), themorningdate);
molast=timetableAuxilary(tr,:);
lastmonthquote=molast(1,:);
mo=molast(end,:).Open;
mc=lastmonthquote.Close;
mlh(1)=lastmonthquote.Low;
mlh(2)=lastmonthquote.High;

colors_mlh={[0 0.8 0 alphalong],[1 0 0 alphalong]};
style_mlh={'-','-'};
dir_mlh=[-1 1];
width_mlh=[3 3];
power_mlh=[3 3];
name_mlh={'MLL','MLH'};
id_mlh=[0x0B00 0x0B01];
%;ticprep=toc
catch exception
   getReport(exception,'extended','hyperlinks','off') 
    
end
%;ticsprep=toc
%;tic;
%% this is for daily pivots
try

%% xxxmor, TDA daily data show a different time stamp, so double check that these act the same way


tr=timerange(themorningdate-days(5), themorningdate-hours(16));
try
ddlast=timetableSecondary(tr,:);
lastdayquote=ddlast(end,:);

% do=timetablePrimary(1,:).Open;
 dc=lastdayquote.Close;
% dlh(1)=lastdayquote.Low;
% dlh(2)=lastdayquote.High;
% dlh
catch
    
end


sma200=0;
sma50=0;
try
sma200=(mean(timetableSecondary(end-199:end-1,:).Close)*199+timetablePrimary.Close(end))/200;
sma50=(mean(timetableSecondary(end-49:end-1,:).Close)*49+timetablePrimary.Close(end))/50;
catch
    
end

smas=[sma50 sma200];
colors_smas={[0 0 1 alphalong],[0 0 1  alphalong]};
style_smas={'-','-'};
dir_smas=[0 0];
width_smas=[2 3];
power_smas=[2 3];
id_smas=[0x0A00 0x0A01];
name_smas={'SMA50','SMA200'};


if (isempty(showbackdateonce) || showbackdateonce==0) 
    showbackdateonce=1;
disp(['using ' datestr(lastmonthquote.Date(end)) ' monthly data for previous month.']);
disp(['using ' datestr(lastdayquote.Date) ' daily data for previous day.']);
end

%% extended dailyhighloq ould be combined

%params.lenPreviousDayPivots=0;
dailyHighLow=zeros(1,params.lenPreviousDayPivots*2);
colors_dailyHighLow=cell(1,params.lenPreviousDayPivots*2);
dir_dailyHighLow=zeros(1,params.lenPreviousDayPivots*2);
width_dailyHighLow=ones(1,params.lenPreviousDayPivots*2);
power_dailyHighLow=zeros(1,params.lenPreviousDayPivots*2);power_dailyHighLow(1:2)=[1,1];
style_dailyHighLow=cell(1,params.lenPreviousDayPivots*2);
name_dailyHighLow=cell(1,params.lenPreviousDayPivots*2);

 for i=1:params.lenPreviousDayPivots
 lastdayquote=ddlast(end+1-i,:);
 dailyHighLow(i*2-1)=lastdayquote.Low;
 dailyHighLow(i*2)=lastdayquote.High;
 colors_dailyHighLow{i*2-1}=[0 0 1  alpha];
 colors_dailyHighLow{i*2}=[0 0 1  alpha];
 style_dailyHighLow{i*2-1}='--';
 style_dailyHighLow{i*2}='--';
 name_dailyHighLow{i*2-1}='DLL';
  name_dailyHighLow{i*2}='DLH';
 dir_dailyHighLow(i*2-1:i*2)=[0 0];%[-1 1];
 x1=(0x0100)+i*2-1;
 x2=(0x0100)+i*2;
 id_dailyHighLow(i*2-1:i*2)=[x1 x2];
 end
 
 
 diffdhl=dailyHighLow(2)-dailyHighLow(1);
catch exception
   getReport(exception,'extended','hyperlinks','off')  
end
%;tic_dlh_sma=toc
%;tic
%% orb levels
try


if (size(timetablePrimary,1)>60) %60 minutes from star
     orb(2)=max(timetablePrimary.High(1:60));
     orb(1)=min(timetablePrimary.Low(1:60));
     colors_orb={[0 1 0  alphalong],[1 0 0 alphalong]};
style_orb={'-','-'};
dir_orb=[0 0];
width_orb=[1 1];
power_orb=[1 1];
id_orb=[0x0200 0x0201];
name_orb={'ORL','ORH'};
else
    orb=[];
        colors_orb={};
style_orb={};
dir_orb=[];
width_orb=[];
power_orb=[];
id_orb=[];
name_orb={}; 
end



% Set process limit after ORB
if (looperParams.processlimit>0)
proclimit_=min(looperParams.processlimit,numel(timetablePrimary.Date)-1);
timetablePrimary=timetablePrimary(end-proclimit_:end,:);

end
tms=size(timetablePrimary,1);
catch exception
   getReport(exception,'extended','hyperlinks','off')
end
%;ticorb=toc
%;tic
%% continue LEVELS

try
   
%sve
msvepivots=SVEPivots(mc,mlh(2),mlh(1));
dsvepivots=SVEPivots(dc,dailyHighLow(2),dailyHighLow(1));
colors_msvepivots={[0 0.8 0 alphalong],[0 0.8 0 alphalong],[0 0.8 0 alphalong],[0 0.8 0 alphalong],[1 0 1 alphalong],[1 0 0 alphalong],[1 0 0 alphalong],[1 0 0 alphalong],[1 0 0 alphalong]};
colors_dsvepivots={[0 0.8 0 alpha],[0 0.8 0 alpha],[0 0.8 0 alpha],[0 0.8 0 alpha],[1 0 1 alpha],[1 0 0 alpha],[1 0 0 alpha],[1 0 0 alpha],[1 0 0 alpha]};
style_svepivots= {'-','-','-','-','-','-','-','-','-'};
dir_svepivots=[-1 1 0 0 0 0 0 -1 1];%[-1 -1 -1 -1 0 1 1 1 1];
width_dsve=[1 1 1 1 1 1 1 1 1];
width_msve=[3 3 3 3 3 3 3 3 3];
power_dsve=[2 2 1 1 1 1 1 2 2];
power_msve=[3 3 2 2 2 2 2 2 2];
id_msve=[0x0300 0x0301 0x0302 0x0303 0x0304 0x0305 0x0306 0x0307 0x0308];
id_dsve=[0x0400 0x0401 0x0402 0x0403 0x0404 0x0405 0x0406 0x0407 0x0408];
name_dsve={'DS4','DS3','DS2','DS1','DPP','DR1','DR2','DR3','DR4'};
name_msve={'MS4','MS3','MS2','MS1','MPP','MR1','MR2','MR3','MR4'};
%woodies
mwpivots=WoodiesPivots(mc,mlh(2),mlh(1));
dwpivots=WoodiesPivots(dc,dailyHighLow(2),dailyHighLow(1));
colors_mwpivots={[0 0.8 0 alphalong],[0 0.8 0 alphalong],[0 0.8 0 alphalong],[0 0.8 0 alphalong],[1 0 1 alphalong],[1 0 0 alphalong],[1 0 0 alphalong],[1 0 0 alphalong],[1 0 0 alphalong]};
colors_dwpivots={[0 0.8 0 alpha],[0 0.8 0 alpha],[0 0.8 0 alpha],[0 0.8 0 alpha],[1 0 1 alpha],[1 0 0 alpha],[1 0 0 alpha],[1 0 0 alpha],[1 0 0 alpha]};
style_wpivots={'--','--','--','--','--','--','--','--','--'};
dir_wpivots=[-1 1 0 0 0 0 0 -1 1];%dir_wpivots=[-1 -1 -1 -1 0 1 1 1 1];
width_dwpivots=[1 1 1 1 1 1 1 1 1];
width_mwpivots=[3 3 3 3 3 3 3 3 3];
power_dwpivots=[2 2 1 1 1 1 1 2 2];
power_mwpivots=[3 3 2 2 2 2 2 3 3];
id_mwpivots=[0x0500 0x0501 0x0502 0x0503 0x0504 0x0505 0x0506 0x0507 0x0508];
id_dwpivots=[0x0600 0x0601 0x0602 0x0603 0x0604 0x0605 0x0606 0x0607 0x0608];

name_dwpivots={'DWS4','DWS3','DWS2','DWS1','DWPP','DWR1','DWR2','DWR3','DWR4'};
name_mwpivots={'MWS4','MWS3','MWS2','MWS1','MWPP','MWR1','MWR2','MWR3','MWR4'};

[hlvls,llvls]=roundLevelsAll(timetablePrimary);
for i=1:2
   dh_{i}=repmat(0,1,numel(hlvls{i}));
   wh_{i}=repmat(i,1,numel(hlvls{i}));
   dl_{i}=repmat(0,1,numel(llvls{i}));
   wl_{i}=repmat(i,1,numel(llvls{i}));
   pl_{i}=repmat(i,1,numel(llvls{i}));
   ph_{i}=repmat(i,1,numel(hlvls{i}));
end
rlvls=[llvls{1} llvls{2} hlvls{1} hlvls{2}];
colors_rlvls=cell(size(rlvls));
style_rlvls=cell(size(rlvls));
name_rlvls=cell(size(rlvls));
for uu=1:numel(rlvls)
    colors_rlvls{uu}=[.5 .5 .5 alpha];
    style_rlvls{uu}='--';
    name_rlvls{uu}='RND';
end
dir_rlvls=[dl_{1} dl_{2} dh_{1} dh_{2}];
width_rlvls=[wl_{1} wl_{2} wh_{1} wh_{2}];
power_rlvls=[pl_{1} pl_{2} ph_{1} ph_{2}];
xx=1:numel(rlvls);
id_rlvls=0x0700+uint16(xx);


catch exception
   getReport(exception,'extended','hyperlinks','off') 
end
%;tictradlevels=toc
%;tic
calculations.levels.values=[dsvepivots msvepivots dwpivots mwpivots orb dailyHighLow rlvls smas mlh];
calculations.levels.color=[colors_dsvepivots colors_msvepivots colors_dwpivots colors_mwpivots colors_orb colors_dailyHighLow colors_rlvls colors_smas colors_mlh];
calculations.levels.style=[style_svepivots  style_svepivots  style_wpivots  style_wpivots  style_orb  style_dailyHighLow  style_rlvls style_smas style_mlh];
calculations.levels.direction=[dir_svepivots dir_svepivots dir_wpivots dir_wpivots dir_orb dir_dailyHighLow dir_rlvls dir_smas dir_mlh];
calculations.levels.width=[width_dsve width_msve width_dwpivots width_mwpivots width_orb width_dailyHighLow width_rlvls width_smas width_mlh];
calculations.levels.power=[power_dsve power_msve power_dwpivots power_mwpivots power_orb power_dailyHighLow power_rlvls power_smas power_mlh];
calculations.levels.id=[id_dsve id_msve id_dwpivots id_mwpivots id_orb id_dailyHighLow id_rlvls id_smas id_mlh];
calculations.levels.name=[name_dsve name_msve name_dwpivots name_mwpivots name_orb name_dailyHighLow name_rlvls name_smas name_mlh];


% sort levels for later additional analysis
[~,sindex]=sort(calculations.levels.values);
calculations.levels.values=calculations.levels.values(sindex);
calculations.levels.color=calculations.levels.color(sindex);
calculations.levels.direction=calculations.levels.direction(sindex);
calculations.levels.width=calculations.levels.width(sindex);
calculations.levels.power=calculations.levels.power(sindex);
calculations.levels.id=calculations.levels.id(sindex);
calculations.levels.style=calculations.levels.style(sindex);
calculations.levels.name=calculations.levels.name(sindex);
%;ticslevels=toc
%;tic

%% find crossings
try

lxup=zeros(tms,size(calculations.levels.values,2));
lxdn=zeros(tms,size(calculations.levels.values,2));
for i=find(calculations.levels.power>0)
    [lxup(:,i),lxdn(:,i)]=crossPivot(timetablePrimary,calculations.levels.values(i));
end

[lxups,lxupi]=max(lxup,[],2); %look into minutesXlevels size array, and fins the largest level has is passed on that minute
[lxdns,lxdni]=max(lxdn,[],2);

%power of levels to cross.. not used for now
lxupp=calculations.levels.power(lxupi)';
lxdnp=calculations.levels.power(lxdni)';

% direction of crossing
lxupd=calculations.levels.direction(lxupi)';
lxdnd=calculations.levels.direction(lxdni)';

lxupd=lxupd>-1;
lxdnd=lxdnd<1;

%remove the ones that are not supposed to cross in that direction
lxups=lxups.*lxupd; %location of breakout happening
lxdns=lxdns.*lxdnd;


if (looperParams.useBookLevels>0)
 if (isfield(params,'marketdata'))
   if (~isempty(params.marketdata))  
    shiftbooklevel=5;
    
    
    bl=params.marketdata.BookLevels;
    bls=size(bl,1);
    if (bls<tms)
       bl(bls:tms,:)=0;
    end
    
    if (bls>tms)
       bl=bl(1:tms,:); 
    end
    
     [lxupb1,lxdnb1]=crossPivot(timetablePrimary,shiftpad(bl(:,1),shiftbooklevel));
    [lxupb2,lxdnb2]=crossPivot(timetablePrimary,shiftpad(bl(:,2), shiftbooklevel));

    lxups=max([lxups,lxupb1,lxupb2],[],2);
    lxdns=max([lxdns,lxdnb1,lxdnb2],[],2);
   end
end
end

catch exception
   getReport(exception,'extended','hyperlinks','off') 
end
%;ticscrossing=toc



%% INDICATORS
 %;tic
try
   



%calculations.indicators{1}.lower=lower_indicators_ideal(timetablePrimary);
%calculations.indicators{1}.upper=upper_indicators_ideal(timetablePrimary);

tempmainticks{1}.params.TimeTables.Minute=timetablePrimary;
tempmainticks{1}.params.TimeTables.Day=timetableSecondary;

tempmainticks{2}.params.TimeTables.Minute=gen2mfrom1m(timetablePrimary,1);
tempmainticks{2}.params.TimeTables.Day=timetableSecondary;

tempmainticks{3}.params.TimeTables.Minute=gen2mfrom1m(timetablePrimary,5);
tempmainticks{3}.params.TimeTables.Day=timetableSecondary;

[mindis,mindislvl]=getmindiscomplex(timetablePrimary,calculations.levels.values);

%%local optima

loWidths=params.localOptimaWidths;%[9,21];%,21,35,50];
loColors={[0.5 0.5 0.5 alpha],[0 0 1 alpha],[0 .75 1 alpha],[0 .75 1 alpha],[0 .75 1 alpha]};
lostyle={':',':',':',':',':'};

tradeGroundTruth_signals_=zeros(size(timetablePrimary.Close));

for i=1:numel(loWidths)
calculations.localOptimaProfile{i}=localOptimaProfiler(loWidths(i),timetablePrimary,1);
calculations.localOptimaProfile{i}.color=loColors{i};
calculations.localOptimaProfile{i}.style=lostyle{i};

%tradeGroundTruth_signals_=tradeGroundTruth_signals_+calculations.localOptimaProfile{i}.tradeGroundTruth_signals;
end

% [~,mind]=max(loWidths);
% 
% sortedIndices=sort(calculations.localOptimaProfile{mind}.indices);
% sortedIndices=[1;sortedIndices;numel(timetablePrimary.Date)];
% overpurchase=0;
% for bb=1:numel(sortedIndices)-1
%     oprice=timetablePrimary.Open(sortedIndices(bb));
%    dprice=timetablePrimary.Close(sortedIndices(bb+1))-oprice;
%    %for now no threshold
%    if (dprice>0 && overpurchase<1)
%        tradeGroundTruth_signals_(sortedIndices(bb))=1;
%        overpurchase=overpurchase+1;
%    end
%       if (dprice<0 && overpurchase>-1)
%        tradeGroundTruth_signals_(sortedIndices(bb))=-1;
%        overpurchase=overpurchase-1;
%    end
% end


noncausalmean=movmean(timetablePrimary.Close,[params.thresh.futureGroundTruthHalfWindowSize_ShortTerm params.thresh.futureGroundTruthHalfWindowSize_ShortTerm]);

futuremax=movmax(noncausalmean,[0 2*params.thresh.futureGroundTruthHalfWindowSize_ShortTerm]);
futuremin=movmin(noncausalmean,[0 2*params.thresh.futureGroundTruthHalfWindowSize_ShortTerm]);

percentilefuturechangemax=(-noncausalmean+futuremax)./diffdhl;
percentilefuturechangemin=(-noncausalmean+futuremin)./diffdhl;

futureonlyhigher=percentilefuturechangemax>=params.thresh.ShortTermPerformance.min;
futureonlylower=percentilefuturechangemin<=-params.thresh.ShortTermPerformance.min;


tradeGroundTruth_signals_(futureonlyhigher)=1;
tradeGroundTruth_signals_(futureonlylower)=-1;

catch exception
   getReport(exception,'extended','hyperlinks','off') 
end
%;ticsindicators=toc
%;tic

%% enter conditions preparation

%;tic
try
absolutevolumethresh=mean(timetableSecondary.Volume(end-30:end))/390;

for i=1:numel(tempparams)
[calculations.indicators{i}.lower,calculations.indicators{i}.upper]=indicators_t8(tempmainticks{i}.params.TimeTables.Minute,tempmainticks{i}.params.TimeTables.Day);
[calculations.indicators{i}.lower.rvs,calculations.indicators{i}.lower.avs]=largevolume(tempmainticks{i}.params.TimeTables.Minute,1*ones(size(tempmainticks{i}.params.TimeTables.Minute.Volume)),absolutevolumethresh); 
calculations.bounce{i}=largebounce(tempmainticks{i}.params.TimeTables.Minute,mindis,calculations.indicators{i}.lower.dvs_fight);
end


[BullCandles, BearCandles ,~] = candlesticksCount(timetablePrimary);
calculations.indicators{1}.lower.BullBearCandleDiff=BullCandles-BearCandles;

BullishCandles=calculations.indicators{1}.lower.BullBearCandleDiff>0;
BearishCandles=calculations.indicators{1}.lower.BullBearCandleDiff<0;


catch exception
   getReport(exception,'extended','hyperlinks','off') 
    
end
%;ticsenter=toc
%;tic
%% process volume buzz

 if (isfield(params,'VolumeBuzzProfile'))
    %genrate minute indices
    minuteindex=1+minutes(timetablePrimary.Date-timetablePrimary.Date(1));
    % grab section of profile that relates
     
    % add it to indicators.lower
    calculations.indicators{1}.lower.VolumeBuzz=movmean(params.VolumeBuzzProfile.Volume(minuteindex),[2 2]);
    calculations.indicators{1}.lower.SellVolumeBuzzRatio= calculations.indicators{1}.lower.SellVolume./calculations.indicators{1}.lower.VolumeBuzz;
    calculations.indicators{1}.lower.BuyVolumeBuzzRatio= calculations.indicators{1}.lower.BuyVolume./calculations.indicators{1}.lower.VolumeBuzz;
    calculations.indicators{1}.lower.VolumeBuzzRatio= timetablePrimary.Volume./calculations.indicators{1}.lower.VolumeBuzz;
    volumebuzzgood=thresholdCondition(calculations.indicators{1}.lower.VolumeBuzzRatio,params.thresh.volumeBuzz,1);
 end




%% gen ground truth (used only for training, but parameter needed in generateNetInputs just ot run without error

%% non-causal buysell signals
tradeGroundTruth_signals_(1)=0;
calculations.indicators{1}.eval.tradeGroundTruth_signals=tradeGroundTruth_signals_;%eros(size(timetablePrimary.Close));
calculations.indicators{1}.eval.tradeGroundTruth_return=signal2return(timetablePrimary,calculations.indicators{1}.eval.tradeGroundTruth_signals);

calculations.indicators{1}.eval.ShortTermPerformance=percentilefuturechangemax;
calculations.indicators{1}.eval.ShortTermPerformance(percentilefuturechangemin<0)=percentilefuturechangemin(percentilefuturechangemin<0);



%% relative Strength
try
    
    %;tic;

if (isfield(params,'graphExtras'))
   nge=numel(params.graphExtras);
   for i=1:nge
    if (params.graphExtras{i}.practice==1)
       for c=1:numel(commonticks)
          if (strcmp(commonticks{c}.params.symbol,params.graphExtras{1}.commontick))
             %calculate relative strength
             calculations.indicators{1}.lower.RelativeStrength=relativeStrength(timetablePrimary,commonticks{c}.params.TimeTables.Minute);
          end
       end
    end
   end
end

catch exception
   getReport(exception,'extended','hyperlinks','off') 
    
end
%;ticsRS=toc


%% exit conditions preparation

%% enter conditions
try
calculations.minDisProfileClose=getsignedmindis(timetablePrimary.Close,calculations.levels.values);
calculations.indicators{1}.lower.CloseFromUpperLevelPercent=(abs(calculations.minDisProfileClose.mindis{2}))*(1)./diffdhl;
calculations.indicators{1}.lower.CloseFromLowerLevelPercent=(abs(calculations.minDisProfileClose.mindis{1}))*(1)./diffdhl;

calculations.minDisProfileOpen=getsignedmindis(timetablePrimary.Open,calculations.levels.values);
calculations.indicators{1}.lower.OpenFromUpperLevelPercent=(abs(calculations.minDisProfileOpen.mindis{2}))*(1)./diffdhl;
calculations.indicators{1}.lower.OpenFromLowerLevelPercent=(abs(calculations.minDisProfileOpen.mindis{1}))*(1)./diffdhl;

calculations.minDisProfileHigh=getsignedmindis(timetablePrimary.High,calculations.levels.values);
calculations.indicators{1}.lower.HighFromUpperLevelPercent=(abs(calculations.minDisProfileHigh.mindis{2}))*(1)./diffdhl;
calculations.indicators{1}.lower.HighFromLowerLevelPercent=(abs(calculations.minDisProfileHigh.mindis{1}))*(1)./diffdhl;

calculations.minDisProfileLow =getsignedmindis(timetablePrimary.Low ,calculations.levels.values);
calculations.indicators{1}.lower.LowFromLowerLevelPercent=(abs(calculations.minDisProfileLow.mindis{1}))*(1)./diffdhl;
calculations.indicators{1}.lower.LowFromUpperLevelPercent=(abs(calculations.minDisProfileLow.mindis{2}))*(1)./diffdhl;

%calculations.indicators{1}.lower.nextLowerLevelFromClose=timetablePrimary.Close-calculations.minDisProfileClose.mindis{1};
%calculations.indicators{1}.lower.nextUpperLevelFromClose=timetablePrimary.Close-calculations.minDisProfileClose.mindis{2};

upNotJumpedTooMuch=calculations.indicators{1}.lower.CloseFromUpperLevelPercent>calculations.indicators{1}.lower.CloseFromLowerLevelPercent;
dnNotJumpedTooMuch=~upNotJumpedTooMuch;

LowestTouched=movmin(timetablePrimary.Low,[5 0]);
HighestTouched=movmin(timetablePrimary.High,[5 0]);

%next upper level from close smaller than highest touched recently, next
%level is basically broken just recently
isNextUpperTouched=calculations.minDisProfileClose.mindislvl{2}<HighestTouched; %idea is if it d touched, we can ignore distance form it
%next lower level from close larger than lowest touched recenrly
isNextLowerTouched=calculations.minDisProfileClose.mindislvl{1}>LowestTouched;

calculations.indicators{1}.lower.BounceUpFromLowerLevelPercent=min([calculations.indicators{1}.lower.LowFromLowerLevelPercent,calculations.indicators{1}.lower.OpenFromLowerLevelPercent,calculations.indicators{1}.lower.OpenFromUpperLevelPercent],[],2);
calculations.indicators{1}.lower.BounceDnFromUpperLevelPercent=min([calculations.indicators{1}.lower.HighFromUpperLevelPercent,calculations.indicators{1}.lower.OpenFromUpperLevelPercent,calculations.indicators{1}.lower.OpenFromLowerLevelPercent],[],2);



goodnextlevel_up_farway= isNextUpperTouched | (calculations.indicators{1}.lower.CloseFromUpperLevelPercent>params.thresh.minNextLvlByPercent);% & calculations.indicators{1}.lower.CloseFromLowerLevelPercent>params.thresh.maxTooCloseByPercent );
goodnextlevel_dn_farway= isNextLowerTouched | (calculations.indicators{1}.lower.CloseFromLowerLevelPercent>params.thresh.minNextLvlByPercent);% & calculations.indicators{1}.lower.CloseFromUpperLevelPercent>params.thresh.maxTooCloseByPercent );

goodlastlevel_up_bounce=calculations.indicators{1}.lower.BounceUpFromLowerLevelPercent<params.thresh.maxLastLvlByPercent;
goodlastlevel_dn_bounce=calculations.indicators{1}.lower.BounceDnFromUpperLevelPercent<params.thresh.maxLastLvlByPercent;

candle_up=timetablePrimary.Close>timetablePrimary.Open;
higherthanhighprev=timetablePrimary.High>shift(timetablePrimary.High,1);
lowerthanlowprev=timetablePrimary.Low<shift(timetablePrimary.Low,1);

for i=1:3
fightup{i}=calculations.bounce{i}.up | thresholdCondition(calculations.indicators{i}.lower.dcs_fight,params.thresh.dcs.fight,1) | thresholdCondition(shift(calculations.indicators{i}.lower.dcs_fight,1),params.thresh.dcs.fight,1);%dcs{i}.fight>params.thresh.dcs.fight.min | shift(dcs{i}.fight,1)>params.thresh.dcs.fight.min;
fightdn{i}=calculations.bounce{i}.dn | thresholdCondition(calculations.indicators{i}.lower.dcs_fight,params.thresh.dcs.fight,0) | thresholdCondition(shift(calculations.indicators{i}.lower.dcs_fight,1),params.thresh.dcs.fight,0);%dcs{i}.fight<-params.thresh.dcs.fight.min | shift(dcs{i}.fight,1)<-params.thresh.dcs.fight.min;
vsgood{i}=volumebuzzgood & (thresholdCondition(calculations.indicators{i}.lower.avs,params.thresh.avs,1) | thresholdCondition(calculations.indicators{i}.lower.rvs,params.thresh.rvs,1));%(avs{i}>params.thresh.avs.min |rvs{i}>params.thresh.rvs.min);
end

%%%xxxmor .,could check against close, or high/low, or check againt lasi
%%%bar data
%shiftedclose=timetablePrimary.Close;
shiftedclose=shiftpad(timetablePrimary.Close,1);

lowerThanBBupper= shiftedclose< calculations.indicators{1}.upper.BBupper;
lowerThanBBupper(isnan(calculations.indicators{1}.upper.BBupper))=1;

%%%xxxmor .,could check against close
higherThanBBlower= shiftedclose> calculations.indicators{1}.upper.BBlower;
higherThanBBlower(isnan(calculations.indicators{1}.upper.BBlower))=1;

notbounceup=~fightup{1} & ~fightup{2}& ~fightup{3};
notbouncedn=~fightdn{1} & ~fightdn{2}& ~fightdn{3};

dsmasettlinglow=thresholdCondition(calculations.indicators{1}.lower.dsma5,params.thresh.dsma5settling,0);% calculations.indicators{1}.lower.dsma5<-params.thresh.dsma5.min;
dsmasettlinghigh=thresholdCondition(calculations.indicators{1}.lower.dsma5,params.thresh.dsma5settling,1);%  calculations.indicators{1}.lower.dsma5>params.thresh.dsma5.min;

dsma5low=thresholdCondition(calculations.indicators{1}.lower.dsma5,params.thresh.dsma5,0);% calculations.indicators{1}.lower.dsma5<-params.thresh.dsma5.min;
dsma5high=thresholdCondition(calculations.indicators{1}.lower.dsma5,params.thresh.dsma5,1);%  calculations.indicators{1}.lower.dsma5>params.thresh.dsma5.min;
ddsma5high=thresholdCondition(calculations.indicators{1}.lower.ddsma5,params.thresh.ddsma5,1);%calculations.indicators{1}.lower.ddsma5>params.thresh.ddsma5.min;
ddsma5low=thresholdCondition(calculations.indicators{1}.lower.ddsma5,params.thresh.ddsma5,0);%calculations.indicators{1}.lower.ddsma5<-params.thresh.ddsma5.min;
hhp=( higherthanhighprev | shift(higherthanhighprev,1));
llp=(lowerthanlowprev | shift(lowerthanlowprev,1));

upcond_break=(calculations.indicators{1}.lower.avs>params.thresh.avs.min.*lxupp |calculations.indicators{1}.lower.rvs>params.thresh.rvs.min.*lxupp) ;% & dvs_close>params.thresh.dvs.close.min & dvs_open>params.thresh.dvs.open.min & dvs_total > params.thresh.dvs.total.min;
dncond_break=(calculations.indicators{1}.lower.avs>params.thresh.avs.min.*lxdnp |calculations.indicators{1}.lower.rvs>params.thresh.rvs.min.*lxdnp) ;% & dvs_close<-params.thresh.dvs.close.min & dvs_open<-params.thresh.dvs.open.min & dvs_total < -params.thresh.dvs.total.min;

overbought=calculations.indicators{1}.lower.rsi10>params.thresh.overboughtPercent.min & calculations.indicators{1}.lower.rsi10<params.thresh.overboughtPercent.max;
oversold=calculations.indicators{1}.lower.rsi10>params.thresh.oversoldPercent.min & calculations.indicators{1}.lower.rsi10<params.thresh.oversoldPercent.max;

for i=1:2

up_dvs_{i}=thresholdCondition(calculations.indicators{i}.lower.dvs_close,params.thresh.dvs.close,1) & thresholdCondition(calculations.indicators{i}.lower.dvs_total,params.thresh.dvs.total,1) & thresholdCondition(calculations.indicators{i}.lower.dvs_open,params.thresh.dvs.open,1);
dn_dvs_{i}=thresholdCondition(calculations.indicators{i}.lower.dvs_close,params.thresh.dvs.close,0) & thresholdCondition(calculations.indicators{i}.lower.dvs_total,params.thresh.dvs.total,0) & thresholdCondition(calculations.indicators{i}.lower.dvs_open,params.thresh.dvs.open,0);
end

up_dvs=up_dvs_{1} | up_dvs_{2};
dn_dvs=dn_dvs_{1} | dn_dvs_{2};

debug.indicatorsNames={'CloseFromUpperLevelPercent','avs{1}','rvs{1}','lxupp','lxdnp',... %1,','2,','3,','4,','5 reference to the condition 1,','2(4),','2(4),','3,','4,','
                  '{1}.dcs_fight','{2}.dcs_fight','{3}.dcs_fight',...
                  'dsma5','ddsma5',... %6,','7,','8
                  '{1}.dcs_close','{2}.dcs_close','{3}.dcs_close',...  %9,','10
                  '{1}.dcs_total','{2}.dcs_total','{3}.dcs_total',...%11,','12
                  '{1}.dcs_open','{2}.dcs_open','{3}.dcs_open',...%13,','14
                  'CloseFromUpperLevelPercent','CloseFromLowerLevelPercent',... %15,'
                  'OpenFromUpperLevelPercent','OpenFromLowerLevelPercent',...
                  'HighFromUpperLevelPercent','LowFromLowerLevelPercent',...
                  'nextLowerLevelFromClose','nextUpperLevelFromClose',...
                  'BullBearCandleDiff','rsi10','calculations.indicators{1}.lower.VolumeBuzzRatio'};

debug.indicators=[calculations.indicators{1}.lower.CloseFromUpperLevelPercent,calculations.indicators{1}.lower.avs,calculations.indicators{1}.lower.rvs,lxupp,lxdnp... %1,2,3,4,5 reference to the condition 1,2(4),2(4),3,4,
                  calculations.indicators{1}.lower.dcs_fight,calculations.indicators{2}.lower.dcs_fight,calculations.indicators{3}.lower.dcs_fight,...
                  calculations.indicators{1}.lower.dsma5,calculations.indicators{1}.lower.ddsma5,... %6,7,8
                  calculations.indicators{1}.lower.dcs_close,calculations.indicators{2}.lower.dcs_close,calculations.indicators{3}.lower.dcs_close,...  %9,10
                  calculations.indicators{1}.lower.dcs_total,calculations.indicators{2}.lower.dcs_total,calculations.indicators{3}.lower.dcs_total,...%11,12
                  calculations.indicators{1}.lower.dcs_open, calculations.indicators{2}.lower.dcs_open,calculations.indicators{3}.lower.dcs_open,...%13,14
                  calculations.indicators{1}.lower.CloseFromUpperLevelPercent,calculations.indicators{1}.lower.CloseFromLowerLevelPercent,... %15
                  calculations.indicators{1}.lower.OpenFromUpperLevelPercent,calculations.indicators{1}.lower.OpenFromLowerLevelPercent,...
                  calculations.indicators{1}.lower.HighFromUpperLevelPercent,calculations.indicators{1}.lower.LowFromLowerLevelPercent,...
                  calculations.minDisProfileClose.mindislvl{1},calculations.minDisProfileClose.mindislvl{2},...
                  calculations.indicators{1}.lower.BullBearCandleDiff,calculations.indicators{1}.lower.rsi10,calculations.indicators{1}.lower.VolumeBuzzRatio];
                

%% more stop related

%xxxmor, high/low may over estimate stop condition, while the stock might
%just bounch back from that high low. Close is better to use, but it will
%under estimate. So, ideally this should become more complicated, and
%consider high/low but only if the price action didn't "fight" back.
%upNextLevelIsReaching= abs(calculations.indicators{1}.lower.HighFromUpperLevelPercent)<params.thresh.maxLastLvlByPercent;
%dnNextLevelIsReaching= abs(calculations.indicators{1}.lower.LowFromLowerLevelPercent)<params.thresh.maxLastLvlByPercent;

upNextLevelIsReaching= abs(calculations.indicators{1}.lower.CloseFromUpperLevelPercent)<params.thresh.maxLastLvlByPercent;
dnNextLevelIsReaching= abs(calculations.indicators{1}.lower.CloseFromLowerLevelPercent)<params.thresh.maxLastLvlByPercent;

upPrevLevelIsReached= abs(calculations.indicators{1}.lower.HighFromLowerLevelPercent)<params.thresh.maxLastLvlByPercent;
dnPrevLevelIsReached= abs(calculations.indicators{1}.lower.LowFromUpperLevelPercent)<params.thresh.maxLastLvlByPercent;

ddsma_lessthanmin=thresholdCondition(calculations.indicators{1}.lower.ddsma5,params.thresh.ddsma5,3);
ddsma_morethan_minusmin=thresholdCondition(calculations.indicators{1}.lower.ddsma5,params.thresh.ddsma5,2);

dret_sma5_close_zerocrossing_up=calculations.indicators{1}.lower.dret_sma5_close>params.thresh.zerocrossing & shiftpad(calculations.indicators{1}.lower.dret_sma5_close,1)<-params.thresh.zerocrossing;
dret_sma5_close_zerocrossing_dn=calculations.indicators{1}.lower.dret_sma5_close<-params.thresh.zerocrossing & shiftpad(calculations.indicators{1}.lower.dret_sma5_close,1)>params.thresh.zerocrossing;

ret_sma5_close_low =thresholdCondition(calculations.indicators{1}.lower.ret_sma5_close,params.thresh.ret_sma5,0);
ret_sma5_close_high=thresholdCondition(calculations.indicators{1}.lower.ret_sma5_close,params.thresh.ret_sma5,1);
%%


debug.AllConditionsnames={ 'goodnextlevel_up_farway', 'upcond_break', 'lxups',... %1', '2', '3
      'dncond_break', 'lxdns',... %4', '5
      'llp', 'fightup{1}', 'candle_up', 'vsgood{1}', 'dsma5low', 'ddsma5high',...%6', '7', '8', '9', '10', '11
      'hhp', 'fightdn{1}', '~candle_up', 'dsma5high', 'ddsma5low',... %12', '13', '14', '15', '16
      'fightup{2}', 'fightdn{2}', 'vsgood{2}',...%17', '18', '19
      'goodnextlevel_dn_farway',... %20
      'up_dvs', 'dn_dvs',...%21', '22
      'dsmasettlinghigh', 'dsmasettlinglow',... %23', '24
      'BullishCandles', 'BearishCandles',...   %25', '26
      'notbounceup', 'notbouncedn',... %27', '28
      'lowerThanBBupper', 'higherThanBBlower ',... %29,30
      'fightup_all','fightdn_all',...               %31,32
      'goodlastlevel_up_bounce','goodlastlevel_dn_bounce',... %33,34
      'upReacingorReachedLevel','dnReachingorReachedLevel',... %35,36
       'ddsma_lessthanmin','ddsma_morethan_minusmin',... %,37,38
       'dnNotJumpedTooMuch','upNotJumpedTooMuch',... %39,40
       'overbought','oversold',... % 41,42
       'dret_sma5_close_zerocrossing_up','dret_sma5_close_zerocrossing_up',... % 43,44
       'ret_sma5_close_low','ret_sma5_close_high',... % 45,46
       'zeros'
      };
 
debug.AllConditions=([goodnextlevel_up_farway,upcond_break,lxups>0,... %1,2,3
     dncond_break,lxdns>0,... %4,5
     llp,fightup{1},candle_up,vsgood{1},dsma5low,ddsma5high,...%6,7,8,9,10,11
     hhp,fightdn{1},~candle_up,dsma5high,ddsma5low,... %12,13,14,15,16
     fightup{2},fightdn{2},vsgood{2},...%17,18,19
     goodnextlevel_dn_farway,... %20
     up_dvs,dn_dvs,...%21,22
     dsmasettlinghigh,dsmasettlinglow,... %23,24
     BullishCandles,BearishCandles,...   %25,26
     notbounceup,notbouncedn,... %27,28
     lowerThanBBupper,higherThanBBlower,... %29,30
     fightup{1}|fightup{2}|fightup{3},fightdn{1}|fightdn{2}|fightdn{3},...%31,32
     goodlastlevel_up_bounce,goodlastlevel_dn_bounce,... %33,34
     (upNextLevelIsReaching|upPrevLevelIsReached),(dnNextLevelIsReaching|dnPrevLevelIsReached),... %35,36
     ddsma_lessthanmin,ddsma_morethan_minusmin,... %,37,38
     dnNotJumpedTooMuch,upNotJumpedTooMuch,... %39,40
     overbought,oversold,... %41,42
     dret_sma5_close_zerocrossing_up,dret_sma5_close_zerocrossing_dn,...  %43,44
     ret_sma5_close_low,ret_sma5_close_high,... % 45,46
     zeros(size(timetablePrimary.Close)) %47, this is to not have a condition
     ]); 

 %xxxmor
 % goodnextlevel_up_farway, goodnextlevel_dn_farway seem to be more common
 % in opposite direction in SPY, lowerThanBBupper, higherThanBBlower gonna
 % be common more in opposite because obvious the bolling bang is not
 % violated in hte opposite direction
 %                                                     hhp       17      20
  
     
     debug.uptrend.totalConditions=debug.AllConditions *params.Strategies.TotalConditions.Conditions.Entry{1};
     debug.dntrend.totalConditions=debug.AllConditions *params.Strategies.TotalConditions.Conditions.Entry{2};
 
     
   calculations.indicators{1}.eval.totalConditions=debug.uptrend.totalConditions-debug.dntrend.totalConditions;
   
   
%  %debug.DirectionCondition{1,1}=[1 ,2 ,3 ,15,11,23,21,28,29]; %upward
% %debug.DirectionCondition{1,2}=[20,4 ,5 ,10,16,24,22,27,30]; 
% debug.DirectionCondition{1,1}=[1 ,2 ,3 ,15,23,21,28,29,42]; %upward
% debug.DirectionCondition{1,2}=[20,4 ,5 ,10,24,22,27,30,41]; 
% debug.DirectionCondition{2,1}=[1 ,31,8 ,9 ,10,11,21,29,33,42]; %upward
% debug.DirectionCondition{2,2}=[20,32,14,15,16,9 ,22,30,34,41];
% %debug.DirectionCondition{3,1}=[1,6,17,8,19,10,11,29];  %upward
% %debug.DirectionCondition{3,2}=[20,12,18,14,19,15,16,30];
debug.DirectionCondition=params.Strategies.Manual.Conditions.Entry;



calculations.DirectionPrediction{1}.Condition=[];
calculations.DirectionPrediction{2}.Condition=[];

for i=1:size(debug.DirectionCondition,1)
    for j=1:size(debug.DirectionCondition,2)
        calculations.DirectionPrediction{j}.Condition(:,i)=min(debug.AllConditions(:,debug.DirectionCondition{i,j}),[],2);
    end
end

catch exception
   getReport(exception,'extended','hyperlinks','off') 
    
end
%;ticscond=toc
%;tic;

try
%% stop conditions

% debug.AllStopConditionsnames={'upNextLevelIsReaching','dnNextLevelIsReaching',...
%     'ddsmagettingsmaller','ddsmagettinglarger',...
%     'candle_up','~candle_up'};
%  
% debug.AllStopConditions=([upNextLevelIsReaching,dnNextLevelIsReaching,...
%     ddsmagettingsmaller,ddsmagettinglarger,...
%     candle_up,~candle_up
%     ]);
 
% debug.StopCondition{1,1}=[35,37,8]; %upward
% debug.StopCondition{1,2}=[36,38,14]; 

% dsma stuff are really under developed here to be used... we want to trakc
% slow down of signal, or change in direction of dsma, which is zero
% crosing f ddsma... candles don't give that. Will have to possibly look at
% reversal of ddsma in between candles

% di=1;
% debug.StopCondition{di,1}=[35,37]; %upward
% debug.StopCondition{di,2}=[36,38]; 
% di=di+1;
% %debug.StopCondition{di,1}=[8,31 ,30,33]; %upward
% %debug.StopCondition{di,2}=[14,32,29,34]; 
% %di=di+1;
% debug.StopCondition{di,1}=[3,43,45]; %upward
% debug.StopCondition{di,2}=[5,44,46]; 
debug.StopCondition=params.Strategies.Manual.Conditions.Exit;


for i=1:size(debug.StopCondition,1)
    for j=1:size(debug.StopCondition,2)
        calculations.StopPrediction{j}.Condition(:,i)=min(debug.AllConditions(:,debug.StopCondition{i,j}),[],2);
    end
end
catch exception
   getReport(exception,'extended','hyperlinks','off') 
    
end
%;ticsstopcond=toc

%;tic



%% net entries

try
    calculations.indicators{1}.eval.net_yRemapped=zeros(size(timetablePrimary.Close));
    calculations.net.DirectionPrediction{1}.final=zeros(size(timetablePrimary.Close));
     calculations.net.DirectionPrediction{2}.final= calculations.net.DirectionPrediction{1}.final;
if (looperParams.net.use==1)
    if (isfield(params.net,'netP1'))
        [calculations.net.X,calculations.net.T,calculations.net.t,calculations.net.indices,calculations.net.viewx]=generateNetInputs(looperParams,params,calculations,commonticks);
        if (~isempty(calculations.net.X))
        
        calculations.net.Y=params.net.netP1(calculations.net.X);
        calculations.net.y=convertTargetTocondensed(calculations.net.Y);
        calculations.net.yRemapped=zeros(size(timetablePrimary.Close));
        calculations.net.yRemapped(calculations.net.indices)=calculations.net.y;
        calculations.indicators{1}.eval.net_yRemapped=calculations.net.yRemapped;
        calculations.net.DirectionPrediction{1}.final=(calculations.net.yRemapped>0.75);
        calculations.net.DirectionPrediction{2}.final=(calculations.net.yRemapped<-0.75);

        end
    end
end

catch
   disp('net failed.');
end

%% conditiondetails

%% automate conditions, and signal types
dircmul=[];

condlen=size(calculations.DirectionPrediction{1}.Condition,2);
dircmul=(0:condlen-1)';
dircmul=pow2(dircmul);
denabled=params.DirectionPredictionEnabled(1:numel(dircmul));
dircmul=dircmul.*denabled;

condlen=size(calculations.StopPrediction{1}.Condition,2);
stopcmul=(0:condlen-1)';
stopcmul=pow2(stopcmul);
denabled=params.StopPredictionEnabled(1:numel(stopcmul));
stopcmul=stopcmul.*denabled;

%;ticscmu=toc

%;tic

%% Process conditions
% for now, I am going to cheat and find the maximum/minimum in the next x minutes
try

calculations.DirectionPrediction{1}.final=calculations.DirectionPrediction{1}.Condition*dircmul |  calculations.indicators{1}.eval.totalConditions>=  params.thresh.totalConditions.min;
calculations.DirectionPrediction{2}.final=calculations.DirectionPrediction{2}.Condition*dircmul |  calculations.indicators{1}.eval.totalConditions<=- params.thresh.totalConditions.min;

calculations.indicators{1}.eval.pbto=(calculations.DirectionPrediction{1}.final>0)  .*timetablePrimary.High;% .* lxups;
calculations.indicators{1}.eval.psto=(calculations.DirectionPrediction{2}.final>0) .*timetablePrimary.Low;% lxdns;

calculations.StopPrediction{1}.final=calculations.StopPrediction{1}.Condition*stopcmul;
calculations.StopPrediction{2}.final=calculations.StopPrediction{2}.Condition*stopcmul;

calculations.indicators{1}.eval.pstc=(calculations.StopPrediction{1}.final>0)  .*calculations.minDisProfileClose.mindislvl{2}; %next upper level from close
calculations.indicators{1}.eval.pbtc=(calculations.StopPrediction{2}.final>0) .*calculations.minDisProfileClose.mindislvl{1}; % next lower level from lcose

prioripoint=0;
calculations.indicators{1}.eval.tradeStrategyBreakoutT8_signals=zeros(tms,1);

 stopsignal= shiftpad( ((calculations.StopPrediction{1}.final>0) | (calculations.StopPrediction{2}.final>0)),1);
   buysellsignal= shiftpad((calculations.DirectionPrediction{1}.final>0)-(calculations.DirectionPrediction{2}.final>0),1);
    buysellsignal2= shiftpad((calculations.net.DirectionPrediction{1}.final>0)-(calculations.net.DirectionPrediction{2}.final>0),1);
for i=1:tms
  
   
   if (stopsignal(i))
       prioripoint=0;
   end
   
   if (buysellsignal2(i)~=0)
       prioripoint=buysellsignal2(i);
   end
   
   if (buysellsignal(i)~=0)
       prioripoint=buysellsignal(i);
   end
    
   calculations.indicators{1}.eval.tradeStrategyBreakoutT8_signals(i)=prioripoint;
   
end

calculations.indicators{1}.eval.tradeStrategyBreakoutT8_signals(end)=0;
calculations.indicators{1}.eval.tradeStrategyBreakoutT8_return=signal2return(timetablePrimary,calculations.indicators{1}.eval.tradeStrategyBreakoutT8_signals);
% tempret=[tick2ret(params.TimeTabls.Minute.Open);0];
% calculations.indicators{1}.eval.tradeStrategyBreakoutT8_return=ret2tick(tempret(2:end))*100;

catch exception
   getReport(exception,'extended','hyperlinks','off') 
    
end
%;ticprocesscond=toc
%;tic;

%commas=repmat(',',size(timetablePrimary.Date,1),1);
%[datestr(timetablePrimary.Date),commas,num2str(calculations.DirectionPrediction{1}.final),commas,num2str(calculations.DirectionPrediction{2}.final),num2str(lxdns), num2str(lxups),num2str(calculations.indicators{1}.lower.dsma5),commas,num2str(calculations.minDisProfileClose.mindis{1}),num2str(calculations.minDisProfileClose.mindis{2}),num2str(calculations.indicators{1}.lower.CloseFromUpperLevelPercent),num2str(debug.AllConditions(:,cond11))]
%[datestr(timetablePrimary.Date),num2str(dcs{1}.fight),num2str(dcs{2}.fight),num2str(avs{1}),num2str(avs{2}),num2str(rvs{1}),num2str(rvs{2}),num2str(calculations.indicators{1}.lower.dsma5),num2str(calculations.indicators{1}.lower.ddsma5),num2str(dvs{1}.close),num2str(dvs{2}.close),num2str(dvs{1}.open),num2str(dvs{2}.open),num2str(dvs{1}.total),num2str(dvs{2}.total)]
%;ticgndtruth=toc

%try for all
catch exception
   getReport(exception,'extended','hyperlinks','off') 
    
end


end

