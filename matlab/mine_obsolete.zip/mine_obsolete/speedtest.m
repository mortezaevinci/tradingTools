close all

 global SYMBOLDONETODAY;
clearvars -except SYMBOLDONETODAY parf;

%looperparams_realtimeD;
%run('config\looperparams_nn_t9_ID3.m');
run('config\looperparams_nn_t9_ID3_offline_allsymbols.m');
%looperEngine.contracts={genContract([],'COMP')};
%looperEngine.contracts={genContract([],'AAPL')};

looperEngine.contracts={...
 genContract([],'AAL'),...
 };

commonticks={};
%main params
run('config\mainparams_backtest_test_t9_STUDY_ID3.m');

patternrec_prepare_t7;

crumb=[];
rq=[];

ntdates_c=0; %% counting the days that worked
ntdates_i=0; %% counting the days that worked
% xxxmor, for last 60 days

numberofdays=2;


 for si=1:ncontracts
initprofile=1;

if (strcmp(looperEngine.contracts{si}.SecType,'IND') || strcmp(looperEngine.contracts{si}.SecType,'FUT'))
continue;
end


  for ds=0:numberofdays
      
 try
 looperEngine.date=datestr(datetime()-days(ds),'yyyy-mm-dd');
 
 if (isbusday(looperEngine.date))
 
     performanceMatrixP1=struct();
     
 looperEngine.dateMinutesNextDay=datetime( looperEngine.date)+days(1);
  disp(looperEngine.date);
 
 %%;tic  
for csi=1:ncommon
   
     disp(['init ' commonticks{csi}.params.contract.Symbol '...']);
    
if (looperEngine.getdatainit==1)
   [rq,c]=getdata_yahoo_func(looperEngine,commonticks{csi}.params,rq,crumb,0,0);
end
    
commonticks{csi}.params=strategy_getdata(looperEngine,commonticks{csi}.params);
 commonticks{csi}.params=loadprofile_PAPP1(commonticks{csi}.params,looperEngine);
end
%%;ticcommonload=toc
 %% evaluate commonticks
%%;tic
for si2=1:ncommon
     
commonticks{si2}.params=strategy_getdata(looperEngine,commonticks{si2}.params);
[commonticks{si}.calculations_daily,commonticks{si}.debug_daily]=strategy_dailytrend_t10(looperEngine,commonticks{si}.params,[]);
commonticks{si2}.calculations=strategy_breakout_t10(looperEngine,commonticks{si2}.params,[],commonticks{si}.calculations_daily);
    end
%%;ticcommonproc=toc

 disp(['init ' filefriendlysymbol(mainticks{si}.params.contract.FileSymbol) '...']);
%%;tic
if (looperEngine.getdatainit==1)
   [rq,c]=getdata_yahoo_func(looperEngine,mainticks{si}.params,rq,crumb,0,0);
end
 %%;ticgetdata=toc

 %%;tic
mainticks{si}.params=strategy_getdata(looperEngine,mainticks{si}.params);
%%;ticload=toc
%%;tic
[mainticks{si}.calculations_daily,mainticks{si}.debug_daily]=strategy_dailytrend_t10(looperEngine,mainticks{si}.params,commonticks);
[mainticks{si}.calculations,mainticks{si}.debug]=strategy_breakout_t10(looperEngine,mainticks{si}.params,commonticks,mainticks{si}.calculations_daily);
%%;ticproc=toc

if (mainticks{si}.calculations.finished)

if (initprofile==1)
initprofile=0;
vsize=size(mainticks{si}.debug.AllConditions,2);
performanceMatrix{si}.conditions.test=zeros(2,size(vsize,2));
performanceMatrix{si}.conditions.trend=zeros(2,size(vsize,2));
performanceMatrix{si}.conditions.testiftrend=zeros(2,size(vsize,2));
performanceMatrix{si}.conditions.trendiftest=zeros(2,size(vsize,2));
performanceMatrix{si}.conditions.testandtrend=zeros(2,size(vsize,2));
vsize=table2array(mainticks{si}.calculations.indicators{1}.lower);
performanceMatrix{si}.indicators.test=zeros(2,size(vsize,2));
performanceMatrix{si}.indicators.trend=zeros(2,size(vsize,2));
performanceMatrix{si}.indicators.testiftrend=zeros(2,size(vsize,2));
performanceMatrix{si}.indicators.trendiftest=zeros(2,size(vsize,2));
performanceMatrix{si}.indicators.testandtrend=zeros(2,size(vsize,2));

algoreturn{si}=1;
end


performanceMatrixP1.conditions=evaluateConditions(mainticks{si}.params,mainticks{si}.calculations,mainticks{si}.debug);

performanceMatrixP1.indicators=evaluateIndicators(mainticks{si}.params,mainticks{si}.calculations);



end

end
catch exception
   getReport(exception,'extended','hyperlinks','on') 
end
  
  end

  
 end 
  
