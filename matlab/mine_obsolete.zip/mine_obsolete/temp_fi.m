ncontracts=numel(testpack);
        
        orders=cell(0);
        ocnt=0;
        
        
        for ci=1:ncontracts
            symbol=testpack{ci}.contract.FileSymbol;
            
            if strcmp(symbol,'ACB')
               ci 
            end
            
        end
        
      