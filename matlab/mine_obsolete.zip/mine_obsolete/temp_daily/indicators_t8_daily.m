function [lower,upper]=indicators_t8(TimeTables)


try
tr=timerange(params.TimeTables.Minute.Date(1)- day(params.TimeTables.Minute.Date(1))-day(28)-day(10), params.TimeTables.Minute.Date(1));
molast=params.TimeTables.Month(tr,:);
lastmonthquote=molast(1,:);

diffdhl=lastmonthquote.High-lastmonthquote.Low;
catch
    
end



    zero=zeros(size(TimeTables.Day.Close));
one=ones(size(TimeTables.Day.Close));
%%upper indicators

try
    
try
%Moving Average 3th - 6th Features
sma5=movavg(TimeTables.Day.Close,'linear',5);
sma5(isnan(sma5))=TimeTables.Day.Open(1);
catch
    sma5=zero;
end
try
sma10 = movavg(TimeTables.Day.Close,'linear',10);
sma10(isnan(sma10))=TimeTables.Day.Open(1);
catch
    sma10=zero;
end
try
sma21 = movavg(TimeTables.Day.Close,'linear',21);
sma21(isnan(sma21))=TimeTables.Day.Open(1);
catch
    sma21=zero;
end
try
sma50 = movavg(TimeTables.Day.Close,'linear',50);
sma50(isnan(sma50))=TimeTables.Day.Open(1);
catch
    sma50=zero;
end



try
%Exponential Moving Average 7 Feature
EMA7 = movavg(TimeTables.Day.Close,'exponential',5);
catch
    EMA7=zero;
end
try

%Time Series Bollinger band 13-15 Features
[BBmiddle,BBupper,BBlower] = bollinger(TimeTables.Day,'WindowSize',20); % standard is 20, but 10 seemed to work better
catch
    BBmiddle.Open=zero;
    BBupper.Open=zero;
    BBlower.Open=zero;
end


try

%Highest high 16 Features
highind = hhigh(TimeTables.Day) ;
catch
    highind.HighestHigh=zero;
end
try
%Lowest low 17 Features
lowind = llow(TimeTables.Day);
catch
    lowind.LowestLow=zero;
end
try
%Median Price 18 Features
MedIdx = medprice(TimeTables.Day);
catch
    MedIdx.MedianPrice=zero;
end
try
%williams Accumulation/Distribution line 21 Features
willadidx = willad(TimeTables.Day);
catch
    willadidx.WillAD=zero;
end




varnames={'sma5','sma10','sma21','sma50',...
    'EMA7',...
    'BBmiddle','BBupper','BBlower','HighestHigh',...
    'LowestLow','MedianIndex',...
    'WillAD'};

%As explained, price today will be used to predict the stock price tomorrow. Hence all the indicators move forward 1 date.
% Only Open price of stock will be considered as feature as it is the only price we know before opening market in the day.
% 1st data point will be removed as there does not have any value for their feature indicators.
upper = timetable(TimeTables.Day.Date, ...
    sma5, sma10, sma21,sma50,...
    EMA7,...
    BBmiddle.Open, BBupper.Open, BBlower.Open, highind.HighestHigh,...
    lowind.LowestLow, MedIdx.MedianPrice ,...
    willadidx.WillAD,...
    'VariableNames',varnames);

catch exception
    % disp('upper indicators failed.');
    exception
     getReport(exception,'extended','hyperlinks','off');
     upper=timetable(TimeTables.Day.Date);
end

%% lower indicator

try

%Extract Technical Indicators
%Relative Strength Index 1st-3th Features


rsi5 = rsindex(TimeTables.Day.Close,'WindowSize',5)/100;
rsi5(isnan(rsi5))=0.5;
catch
   rsi5=one*0.5; 
end
try
rsi10 = rsindex(TimeTables.Day.Close,'WindowSize',10)/100;
rsi10(isnan(rsi10))=0.5;
catch
   rsi10=one*0.5; 
end
try
rsi21 = rsindex(TimeTables.Day.Close,'WindowSize',21)/100;
rsi21(isnan(rsi21))=0.5;
catch
   rsi21=one*0.5; 
end
try

%Moving Average Convergent/Divergent 8-9th Features
[MACDLine, signalLine]= macd(TimeTables.Day.Close);
MACDLine(isnan(MACDLine))=0;

%signal line could be different in size
%signalLine(isnan(signalLine))=0;

catch
 % signalLine =zero; 
  MACDLine=zero;
end
try
%Negative Volume Index 10th Features
NVIind = negvolidx(TimeTables.Day);
catch
  NVIind.NegativeVolume =zero; 
end
try
%Positive Volume Index 11th Features
PosVind = posvolidx(TimeTables.Day);
catch
 PosVind.PositiveVolume  =zero; 
end
try
%Accumulation/Distribution OSciallator 12th Features
ADOsc = adosc(TimeTables.Day);
catch
  ADOsc.ADOscillator =zero; 
end
try
%on-balance volume 19 Features
volumeIdx = onbalvol(TimeTables.Day);
catch
  volumeIdx.OnBalanceVolume =zero; 
end
try
%Price and Volume Trend(PVT) 20 Features
pvtInd = pvtrend(TimeTables.Day); 
catch
  pvtInd.PriceVolumeTrend =zero; 
end
try
%Ticket Return Series 22 Features
tt_tick2retidx = tick2ret(TimeTables.Day);
a_tick2retidx=table2array(tt_tick2retidx);
a_tick2retidx=[zeros(1,size(a_tick2retidx,2));a_tick2retidx];
catch
  a_tick2retidx =zeros(size(TimeTables.Day)); 
end
try
%Chaikin Volatility 23
volatility = chaikvolat(TimeTables.Day);
volatility.ChaikinVolatility(isnan(volatility.ChaikinVolatility))=0;
catch
  volatility.ChaikinVolatility =zero; 
end
try
%Stochastic Oscillator 24
percentKnD = stochosc(TimeTables.Day);
catch
   percentKnD.FastPercentK=zero; 
end
try
%Acceleration between times 25
acceleration = tsaccel(TimeTables.Day);
catch
 acceleration.Open  =zero; 
end
try
%Momentum between times 26
momentum = tsmom(TimeTables.Day);
catch
  momentum.Open =zero; 
end

%coming from upper

try

    
shiftedsma5=shiftpad(upper.sma5,5);
dsma5=(upper.sma5-shiftedsma5)*(1)/diffdhl;%./TimeTables.Day.Close;
dsma5(1:min(4,size(dsma5,1)),1)=0;
ddsma5=dsma5- shiftpad(dsma5,1);%[dsma5(1);dsma5(1:end-1)];

dcs=largedcandle(TimeTables.Day);
dvs=largedvol(TimeTables.Day,0.1);

% calculations.indicators{1}.lower.dcs1_fight=dcs{1}.fight;
% calculations.indicators{1}.lower.dcs1_open=dcs{1}.open;
% calculations.indicators{1}.lower.dcs1_close=dcs{1}.close;
% calculations.indicators{1}.lower.dcs1_total=dcs{1}.total;
% calculations.indicators{1}.lower.dvs1_fight=dvs{1}.fight;
% calculations.indicators{1}.lower.dvs1_open=dvs{1}.open;
% calculations.indicators{1}.lower.dvs1_close=dvs{1}.close;
% calculations.indicators{1}.lower.dvs1_total=dvs{1}.total;
    


sma5ret = tick2ret(sma5);
sma5ret=[zeros(1,size(sma5ret,2));sma5ret];

sma10ret = tick2ret(sma10);
sma10ret=[zeros(1,size(sma10ret,2));sma10ret];

sma21ret = tick2ret(sma21);
sma21ret=[zeros(1,size(sma21ret,2));sma21ret];

sma50ret = tick2ret(sma50);
sma50ret=[zeros(1,size(sma50ret,2));sma50ret];

BBupperret = tick2ret(BBupper.Open);
BBupperret=[zeros(1,size(BBupperret,2));BBupperret];

BBlowerret = tick2ret(BBlower.Open);
BBlowerret=[zeros(1,size(BBlowerret,2));BBlowerret];


PercentileBollingerBW=(BBupper.Open-BBlower.Open)./BBmiddle.Open;

varnames={'rsi5','rsi10','rsi21',...
'sma5ret','sma10ret','sma21ret','sma50ret',...
'BBlowerret','BBupperret','PercentileBollingerBW',...
    'dsma5','ddsma5',...
    'MACD',...
    'NVI','PVI','ADO',...
   'PriceVolumeTrend',...
    'OnBalanceVolume','tick2ret',...
    'ChaikinVolatility','FastPercentK','acceleration',...
    'momentum',...
    'dcs_fight','dcs_open','dcs_close','dcs_total',...
    'dvs_fight','dvs_open','dvs_close','dvs_total',...
    };

%As explained, price today will be used to predict the stock price tomorrow. Hence all the indicators move forward 1 date.
% Only Open price of stock will be considered as feature as it is the only price we know before opening market in the day.
% 1st data point will be removed as there does not have any value for their feature indicators.
lower = timetable(TimeTables.Day.Date, ...
rsi5, rsi10, rsi21,...
sma5ret,sma10ret,sma21ret,sma50ret,...
BBlowerret,BBupperret,PercentileBollingerBW,...
   dsma5,ddsma5,...
    MACDLine,...
    NVIind.NegativeVolume, PosVind.PositiveVolume, ADOsc.ADOscillator,...
    pvtInd.PriceVolumeTrend,...
     volumeIdx.OnBalanceVolume, a_tick2retidx,...
     volatility.ChaikinVolatility, percentKnD.FastPercentK, acceleration.Open,...
     momentum.Open,...
     dcs.fight,dcs.open,dcs.close,dcs.total,...
     dvs.fight,dvs.open,dvs.close,dcs.total,...
     'VariableNames',varnames);
catch exception
     %disp('lower indicators failed.');
     exception
      getReport(exception,'extended','hyperlinks','off');
     lower=timetable(TimeTables.Day.Date);
end
end