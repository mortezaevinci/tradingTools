function [calculations,debug]=strategy_breakout_t8(looperParams,params,commonticks)

debug=[];
try
calculations.started=1;


global showbackdateonce;

%;tic;
%% preperation
try
%;tic
% for monthly pivots
tr=timerange(params.TimeTables.Minute.Date(1)- day(params.TimeTables.Minute.Date(1))-day(28)-day(10), params.TimeTables.Minute.Date(1));
molast=params.TimeTables.Month(tr,:);
lastmonthquote=molast(1,:);
mo=molast(end,:).Open;
mc=lastmonthquote.Close;
mlh(1)=lastmonthquote.Low;
mlh(2)=lastmonthquote.High;

colors_mlh={'g','r'};
style_mlh={'-','-'};
dir_mlh=[-1 1];
width_mlh=[3 3];
power_mlh=[3 3];
name_mlh={'MLL','MLH'};
id_mlh=[0x0B00 0x0B01];
%;ticprep=toc
catch exception
   getReport(exception,'extended','hyperlinks','off') 
    
end
%;ticsprep=toc
%;tic;
%% this is for daily pivots
try
%;tic;

sma200=0;
sma50=0;
try
sma200=(mean(params.TimeTables.Day(end-199:end-1,:).Close))/200;
sma50=(mean(params.TimeTables.Day(end-49:end-1,:).Close))/50;
catch
    
end

smas=[sma50 sma200];
colors_smas={'b','b'};
style_smas={'-','-'};
dir_smas=[0 0];
width_smas=[2 3];
power_smas=[2 3];
id_smas=[0x0A00 0x0A01];
name_smas={'SMA50','SMA200'};


if (isempty(showbackdateonce) || showbackdateonce==0) 
    showbackdateonce=1;
disp(['using ' datestr(lastmonthquote.Date(end)) ' monthly data for previous month.']);
disp(['using ' datestr(lastdayquote.Date) ' daily data for previous day.']);
end

%;tic
%% orb levels
try

% Set process limit after ORB
if (looperParams.processlimit>0)
proclimit_=min(looperParams.processlimit,numel(params.TimeTables.Day.Date)-1);
params.TimeTables.Day=params.TimeTables.Day(end-proclimit_:end,:);

end
tms=size(params.TimeTables.Day,1);
catch exception
   getReport(exception,'extended','hyperlinks','off')
end
%;ticorb=toc
%;tic
%% continue LEVELS

try
   
%sve
msvepivots=SVEPivots(mc,mlh(2),mlh(1));
d
colors_svepivots={'g','g','g','g','m','r','r','r','r'};
style_svepivots= {'-','-','-','-','-','-','-','-','-'};
dir_svepivots=[-1 1 0 0 0 0 0 -1 1];%[-1 -1 -1 -1 0 1 1 1 1];
width_msve=[3 3 3 3 3 3 3 3 3];
power_msve=[3 3 2 2 2 2 2 2 2];
id_msve=[0x0300 0x0301 0x0302 0x0303 0x0304 0x0305 0x0306 0x0307 0x0308];
name_msve={'MS4','MS3','MS2','MS1','MPP','MR1','MR2','MR3','MR4'};
%woodies
mwpivots=WoodiesPivots(mo,mlh(2),mlh(1));

colors_wpivots={'g','g','g','g','m','r','r','r','r'};
style_wpivots={'--','--','--','--','--','--','--','--','--'};
dir_wpivots=[-1 1 0 0 0 0 0 -1 1];%dir_wpivots=[-1 -1 -1 -1 0 1 1 1 1];

width_mwpivots=[3 3 3 3 3 3 3 3 3];
power_mwpivots=[3 3 2 2 2 2 2 3 3];
id_mwpivots=[0x0500 0x0501 0x0502 0x0503 0x0504 0x0505 0x0506 0x0507 0x0508];
name_mwpivots={'MWS4','MWS3','MWS2','MWS1','MWPP','MWR1','MWR2','MWR3','MWR4'};

[hlvls,llvls]=roundLevelsAll(params.TimeTables.Day);
for i=1:2
   %ch_{i}=repmat('k--',1,numel(hlvls{i}));
   dh_{i}=repmat(0,1,numel(hlvls{i}));
   wh_{i}=repmat(i,1,numel(hlvls{i}));
   %cl_{i}=repmat('k--',1,numel(llvls{i}));
   dl_{i}=repmat(0,1,numel(llvls{i}));
   wl_{i}=repmat(i,1,numel(llvls{i}));
   pl_{i}=repmat(i,1,numel(llvls{i}));
   ph_{i}=repmat(i,1,numel(hlvls{i}));
end
rlvls=[llvls{1} llvls{2} hlvls{1} hlvls{2}];
colors_rlvls=cell(size(rlvls));
style_rlvls=cell(size(rlvls));
name_rlvls=cell(size(rlvls));
for uu=1:numel(rlvls)
    colors_rlvls{uu}='k';
    style_rlvls{uu}='--';
    name_rlvls{uu}='RND';
end
dir_rlvls=[dl_{1} dl_{2} dh_{1} dh_{2}];
width_rlvls=[wl_{1} wl_{2} wh_{1} wh_{2}];
power_rlvls=[pl_{1} pl_{2} ph_{1} ph_{2}];
xx=1:numel(rlvls);
id_rlvls=0x0700+uint16(xx);

%;tictradlevels=toc
catch exception
   getReport(exception,'extended','hyperlinks','off') 
end


calculations.levels.values=[ msvepivots  mwpivots orb  rlvls smas mlh];
calculations.levels.color=[ colors_svepivots  colors_wpivots   colors_rlvls colors_smas colors_mlh];
calculations.levels.style=[  style_svepivots    style_wpivots      style_rlvls style_smas style_mlh];
calculations.levels.direction=[ dir_svepivots  dir_wpivots   dir_rlvls dir_smas dir_mlh];
calculations.levels.width=[ width_msve  width_mwpivots   width_rlvls width_smas width_mlh];
calculations.levels.power=[ power_msve  power_mwpivots   power_rlvls power_smas power_mlh];
calculations.levels.id=[ id_msve  id_mwpivots   id_rlvls id_smas id_mlh];
calculations.levels.name=[ name_msve  name_mwpivots   name_rlvls name_smas name_mlh];


% sort levels for later additional analysis
[~,sindex]=sort(calculations.levels.values);
calculations.levels.values=calculations.levels.values(sindex);
calculations.levels.color=calculations.levels.color(sindex);
calculations.levels.direction=calculations.levels.direction(sindex);
calculations.levels.width=calculations.levels.width(sindex);
calculations.levels.power=calculations.levels.power(sindex);
calculations.levels.id=calculations.levels.id(sindex);
calculations.levels.style=calculations.levels.style(sindex);
calculations.levels.name=calculations.levels.name(sindex);
%;ticslevels=toc
%;tic

%% find crossings
try

lxup=zeros(tms,size(calculations.levels.values,2));
lxdn=zeros(tms,size(calculations.levels.values,2));
for i=find(calculations.levels.power>0)
    [lxup(:,i),lxdn(:,i)]=crossPivot(params.TimeTables.Day,calculations.levels.values(i));
end

[lxups,lxupi]=max(lxup,[],2);
[lxdns,lxdni]=max(lxdn,[],2);

%power of levels to cross.. not used for now
lxupp=calculations.levels.power(lxupi)';
lxdnp=calculations.levels.power(lxdni)';

% direction of crossing
lxupd=calculations.levels.direction(lxupi)';
lxdnd=calculations.levels.direction(lxdni)';

lxupd=lxupd>-1;
lxdnd=lxdnd<1;

%remove the ones that are not supposed to cross in that direction
lxups=lxups.*lxupd;
lxdns=lxdns.*lxdnd;



catch exception
   getReport(exception,'extended','hyperlinks','off') 
end


% nlvls=numel(calculations.levels.values);
% maxup=calculations.levels.values(nlvls)*2;
% lxupiNext=lxupi+1;
% lxupiNext(lxupiNext==0)=1;
% lxupNext=calculations.levels.values(lxupiNext)';
% lxupNext(lxupi==nlvls | lxupi==1)=maxup;
% 
% lxdniNext=lxdni-1;
% lxdniNext(lxdniNext==0)=1;
% lxdnNext=calculations.levels.values(lxdniNext)';
% lxdnNext(lxdni==1)=0;
%;ticsx=toc
%;tic

%% INDICATORS
try
    %;tic
[calculations.indicators{1}.lower.BuyVolume,calculations.indicators{1}.lower.SellVolume]=buysellVolume(params.TimeTables.Day,0);

%calculations.indicators{1}.lower=lower_indicators_ideal(params.TimeTables.Minute);
%calculations.indicators{1}.upper=upper_indicators_ideal(params.TimeTables.Minute);

params2.TimeTables.Day=gen2mfrom1m(params.TimeTables.Day,1);
params2.TimeTables.Day=params.TimeTables.Day;
[calculations.indicators{1}.lower,calculations.indicators{1}.upper]=indicators_t8_daily(params.TimeTables);
[calculations.indicators{2}.lower,calculations.indicators{2}.upper]=indicators_t8_daily(params2.TimeTables);

[mindis,mindislvl]=getmindiscomplex(params.TimeTables.Day,calculations.levels.values);

%%local optima

loWidths=params.localOptimaWidths;%[9,21];%,21,35,50];
loColors={'k','b','c','c','c'};
lostyle={':',':',':',':',':'};

tradeGroundTruth_signals_=zeros(size(params.TimeTables.Day.Close));

for i=1:numel(loWidths)
calculations.localOptimaProfile{i}=localOptimaProfiler(loWidths(i),params.TimeTables.Day,1);
calculations.localOptimaProfile{i}.color=loColors{i};
calculations.localOptimaProfile{i}.style=lostyle{i};

%tradeGroundTruth_signals_=tradeGroundTruth_signals_+calculations.localOptimaProfile{i}.tradeGroundTruth_signals;
end

[~,mind]=max(loWidths);

sortedIndices=sort(calculations.localOptimaProfile{mind}.indices);
sortedIndices=[1;sortedIndices;numel(params.TimeTables.Day.Date)];
overpurchase=0;
for bb=1:numel(sortedIndices)-1
    oprice=params.TimeTables.Day.Open(sortedIndices(bb));
   dprice=params.TimeTables.Day.Close(sortedIndices(bb+1))-oprice;
   %for now no threshold
   if (dprice>0 && overpurchase<1)
       tradeGroundTruth_signals_(sortedIndices(bb))=1;
       overpurchase=overpurchase+1;
   end
      if (dprice<0 && overpurchase>-1)
       tradeGroundTruth_signals_(sortedIndices(bb))=-1;
       overpurchase=overpurchase-1;
   end
end


noncausalmean=movmean(params.TimeTables.Day.Close,[5 5]);

futuremax=movmax(noncausalmean,[0 10]);
futuremin=movmin(noncausalmean,[0 10]);

thresh=0.01;

percentilefuturechangemax=(-noncausalmean+futuremax)./noncausalmean;

percentilefuturechangemin=(-noncausalmean+futuremin)./noncausalmean;

futureonlyhigher=percentilefuturechangemax>=thresh;
futureonlylower=percentilefuturechangemin<=-thresh;

calculations.indicators{1}.eval.ShortTermPerformance=percentilefuturechangemax;
calculations.indicators{1}.eval.ShortTermPerformance(percentilefuturechangemin<0)=percentilefuturechangemin(percentilefuturechangemin<0);

tradeGroundTruth_signals_(futureonlyhigher)=1;
tradeGroundTruth_signals_(futureonlylower)=-1;

%;ticindicators=toc
catch exception
   getReport(exception,'extended','hyperlinks','off') 
end
%;ticsindicators=toc
%;tic
%% relative Strength
try
    
    %;tic;

if (isfield(params,'graphExtras'))
   nge=numel(params.graphExtras);
   for i=1:nge
    if (params.graphExtras{i}.practice==1)
       for c=1:numel(commonticks)
          if (strcmp(commonticks{c}.params.symbol,params.graphExtras{1}.commontick))
             %calculate relative strength
             calculations.indicators{1}.lower.RelativeStrength=relativeStrength(params.TimeTables.Day,commonticks{c}.params.TimeTables.Minute);
          end
       end
    end
   end
end
%;ticrs=toc
catch exception
   getReport(exception,'extended','hyperlinks','off') 
    
end
%;ticsRS=toc

%% enter conditions preparation
try
    %;tic;
%calculations.indicators{1}.lower.dsma5=(calculations.indicators{1}.upper.sma5-[calculations.indicators{1}.upper.sma5(1);calculations.indicators{1}.upper.sma5(1);calculations.indicators{1}.upper.sma5(1);calculations.indicators{1}.upper.sma5(1);calculations.indicators{1}.upper.sma5(1);calculations.indicators{1}.upper.sma5(1:end-5)])*100./params.TimeTables.Minute.Close;

%shiftedsma5=shift(calculations.indicators{1}.upper.sma5,5);
%calculations.indicators{1}.lower.dsma5=(calculations.indicators{1}.upper.sma5-shiftedsma5)*100./params.TimeTables.Minute.Close;
%calculations.indicators{1}.lower.dsma5(1:min(4,size(calculations.indicators{1}.lower.dsma5,1)),1)=0;
%calculations.indicators{1}.lower.ddsma5=calculations.indicators{1}.lower.dsma5-[calculations.indicators{1}.lower.dsma5(1);calculations.indicators{1}.lower.dsma5(1:end-1)];
absolutevolumethresh=mean(params.TimeTables.Day.Volume(end-90:end));

%dcs{1}=largedcandle(params.TimeTables.Minute);
%dvs{1}=largedvol(params.TimeTables.Minute,0.1);
[rvs{1},avs{1}]=largevolume(params.TimeTables.Day,1*ones(size(params.TimeTables.Day.Volume)),absolutevolumethresh); 
calculations.bounce{1}=largebounce(params.TimeTables.Day,mindis,calculations.indicators{1}.lower.dvs_fight);

%dcs{2}=largedcandle(params2.TimeTables.Minute);
%dvs{2}=largedvol(params2.TimeTables.Minute,0.1);
[rvs{2},avs{2}]=largevolume(params2.TimeTables.Day,1*ones(size(params.TimeTables.Day.Volume)),absolutevolumethresh);
calculations.bounce{2}=largebounce(params2.TimeTables.Day,mindis,calculations.indicators{2}.lower.dvs_fight);

% calculations.indicators{1}.lower.dcs1_fight=dcs{1}.fight;
% calculations.indicators{1}.lower.dcs1_open=dcs{1}.open;
% calculations.indicators{1}.lower.dcs1_close=dcs{1}.close;
% calculations.indicators{1}.lower.dcs1_total=dcs{1}.total;
% calculations.indicators{1}.lower.dvs1_fight=dvs{1}.fight;
% calculations.indicators{1}.lower.dvs1_open=dvs{1}.open;
% calculations.indicators{1}.lower.dvs1_close=dvs{1}.close;
% calculations.indicators{1}.lower.dvs1_total=dvs{1}.total;
calculations.indicators{1}.lower.rvs=rvs{1};
calculations.indicators{1}.lower.avs=avs{1};

% calculations.indicators{1}.lower.dcs2_fight=dcs{2}.fight;
% calculations.indicators{1}.lower.dcs2_open=dcs{2}.open;
% calculations.indicators{1}.lower.dcs2_close=dcs{2}.close;
% calculations.indicators{1}.lower.dcs2_total=dcs{2}.total;
% calculations.indicators{1}.lower.dvs2_fight=dvs{2}.fight;
% calculations.indicators{1}.lower.dvs2_open=dvs{2}.open;
% calculations.indicators{1}.lower.dvs2_close=dvs{2}.close;
% calculations.indicators{1}.lower.dvs2_total=dvs{2}.total;
calculations.indicators{2}.lower.rvs=rvs{2};
calculations.indicators{2}.lower.avs=avs{2};

%candlesticksCount(mainticks{1}.params.TimeTables.Minute);

[BullCandles, BearCandles ,~] = candlesticksCount(params.TimeTables.Day);

calculations.indicators{1}.lower.BullBearCandleDiff=BullCandles-BearCandles;

BullishCandles=calculations.indicators{1}.lower.BullBearCandleDiff>0;
BearishCandles=calculations.indicators{1}.lower.BullBearCandleDiff<0;


% bullindex=cell2mat(bull);
% bearindex=cell2mat(bear);
% bullcond=zeros(size(params.TimeTables.Minute.Date));
% bearcond=bullcond;
% bullcond(bullindex)=1;
% bearcond(bearindex)=1;


%;ticEnterPrep=toc
catch exception
   getReport(exception,'extended','hyperlinks','off') 
    
end
%;ticsenter=toc
%;tic

%% exit conditions preparation

%% enter conditions
try
    %;tic;
calculations.minDisProfileClose=getsignedmindis(params.TimeTables.Day.Close,calculations.levels.values);
calculations.indicators{1}.lower.CloseFromUpperLevelPercent=(abs(calculations.minDisProfileClose.mindis{2}))*(1)./diffdhl;
calculations.indicators{1}.lower.CloseFromLowerLevelPercent=(abs(calculations.minDisProfileClose.mindis{1}))*(1)./diffdhl;

calculations.minDisProfileOpen=getsignedmindis(params.TimeTables.Day.Open,calculations.levels.values);
calculations.indicators{1}.lower.OpenFromUpperLevelPercent=(abs(calculations.minDisProfileOpen.mindis{2}))*(1)./diffdhl;
calculations.indicators{1}.lower.OpenFromLowerLevelPercent=(abs(calculations.minDisProfileOpen.mindis{1}))*(1)./diffdhl;

calculations.minDisProfileHigh=getsignedmindis(params.TimeTables.Day.High,calculations.levels.values);
calculations.indicators{1}.lower.HighFromUpperLevelPercent=(abs(calculations.minDisProfileHigh.mindis{2}))*(1)./diffdhl;
calculations.indicators{1}.lower.HighFromLowerLevelPercent=(abs(calculations.minDisProfileHigh.mindis{1}))*(1)./diffdhl;

calculations.minDisProfileLow =getsignedmindis(params.TimeTables.Day.Low ,calculations.levels.values);
calculations.indicators{1}.lower.LowFromLowerLevelPercent=(abs(calculations.minDisProfileLow.mindis{1}))*(1)./diffdhl;
calculations.indicators{1}.lower.LowFromUpperLevelPercent=(abs(calculations.minDisProfileLow.mindis{2}))*(1)./diffdhl;

%calculations.indicators{1}.lower.nextLowerLevelFromClose=params.TimeTables.Minute.Close-calculations.minDisProfileClose.mindis{1};
%calculations.indicators{1}.lower.nextUpperLevelFromClose=params.TimeTables.Minute.Close-calculations.minDisProfileClose.mindis{2};

LowestTouched=movmin(params.TimeTables.Day.Low,[5 0]);
HighestTouched=movmin(params.TimeTables.Day.High,[5 0]);

%next upper level from close smaller than highest touched recently
isNextUpperTouched=calculations.minDisProfileClose.mindislvl{2}<HighestTouched; %idea is if it d touched, we can ignore distance form it
%next lower level from close larger than lowest touched recenrly
isNextLowerTouched=calculations.minDisProfileClose.mindislvl{1}>LowestTouched;

calculations.indicators{1}.lower.BounceUpFromLowerLevelPercent=min(calculations.indicators{1}.lower.LowFromLowerLevelPercent,calculations.indicators{1}.lower.OpenFromLowerLevelPercent);
calculations.indicators{1}.lower.BounceDnFromUpperLevelPercent=min(calculations.indicators{1}.lower.HighFromUpperLevelPercent,calculations.indicators{1}.lower.OpenFromUpperLevelPercent);



goodnextlevel_up_farway= isNextUpperTouched | calculations.indicators{1}.lower.CloseFromUpperLevelPercent>params.thresh.minNextLvlByPercent;
goodnextlevel_dn_farway= isNextLowerTouched | calculations.indicators{1}.lower.CloseFromLowerLevelPercent>params.thresh.minNextLvlByPercent;

goodlastlevel_up_bounce=calculations.indicators{1}.lower.BounceUpFromLowerLevelPercent<params.thresh.maxLastLvlByPercent;
goodlastlevel_dn_bounce=calculations.indicators{1}.lower.BounceDnFromUpperLevelPercent<params.thresh.maxLastLvlByPercent;

candle_up=params.TimeTables.Day.Close>params.TimeTables.Day.Open;
higherthanhighprev=params.TimeTables.Day.High>shift(params.TimeTables.Day.High,1);
lowerthanlowprev=params.TimeTables.Day.Low<shift(params.TimeTables.Day.Low,1);

for i=1:2
fightup{i}=calculations.bounce{i}.up | thresholdCondition(calculations.indicators{i}.lower.dcs_fight,params.thresh.dcs.fight,1) | thresholdCondition(shift(calculations.indicators{i}.lower.dcs_fight,1),params.thresh.dcs.fight,1);%dcs{i}.fight>params.thresh.dcs.fight.min | shift(dcs{i}.fight,1)>params.thresh.dcs.fight.min;
fightdn{i}=calculations.bounce{i}.dn | thresholdCondition(calculations.indicators{i}.lower.dcs_fight,params.thresh.dcs.fight,0) | thresholdCondition(shift(calculations.indicators{i}.lower.dcs_fight,1),params.thresh.dcs.fight,0);%dcs{i}.fight<-params.thresh.dcs.fight.min | shift(dcs{i}.fight,1)<-params.thresh.dcs.fight.min;
vsgood{i}=thresholdCondition(avs{i},params.thresh.avs,1) | thresholdCondition(rvs{i},params.thresh.rvs,1);%(avs{i}>params.thresh.avs.min |rvs{i}>params.thresh.rvs.min);
end

lowerThanBBupper= params.TimeTables.Day.Close< calculations.indicators{1}.upper.BBupper;
lowerThanBBupper(isnan(calculations.indicators{1}.upper.BBupper))=1;

higherThanBBlower= params.TimeTables.Day.Close> calculations.indicators{1}.upper.BBlower;
higherThanBBlower(isnan(calculations.indicators{1}.upper.BBlower))=1;



notbounceup=~fightup{1} & ~fightup{2};
notbouncedn=~fightdn{1} & ~fightdn{2};


dsmasettlinglow=thresholdCondition(calculations.indicators{1}.lower.dsma5,params.thresh.dsma5settling,0);% calculations.indicators{1}.lower.dsma5<-params.thresh.dsma5.min;
dsmasettlinghigh=thresholdCondition(calculations.indicators{1}.lower.dsma5,params.thresh.dsma5settling,1);%  calculations.indicators{1}.lower.dsma5>params.thresh.dsma5.min;

dsma5low=thresholdCondition(calculations.indicators{1}.lower.dsma5,params.thresh.dsma5,0);% calculations.indicators{1}.lower.dsma5<-params.thresh.dsma5.min;
dsma5high=thresholdCondition(calculations.indicators{1}.lower.dsma5,params.thresh.dsma5,1);%  calculations.indicators{1}.lower.dsma5>params.thresh.dsma5.min;
ddsma5high=thresholdCondition(calculations.indicators{1}.lower.ddsma5,params.thresh.ddsma5,1);%calculations.indicators{1}.lower.ddsma5>params.thresh.ddsma5.min;
ddsma5low=thresholdCondition(calculations.indicators{1}.lower.ddsma5,params.thresh.ddsma5,0);%calculations.indicators{1}.lower.ddsma5<-params.thresh.ddsma5.min;
hhp=( higherthanhighprev | shift(higherthanhighprev,1));
llp=(lowerthanlowprev | shift(lowerthanlowprev,1));

upcond_break=(avs{1}>params.thresh.avs.min.*lxupp |rvs{1}>params.thresh.rvs.min.*lxupp) ;% & dvs_close>params.thresh.dvs.close.min & dvs_open>params.thresh.dvs.open.min & dvs_total > params.thresh.dvs.total.min;
dncond_break=(avs{1}>params.thresh.avs.min.*lxdnp |rvs{1}>params.thresh.rvs.min.*lxdnp) ;% & dvs_close<-params.thresh.dvs.close.min & dvs_open<-params.thresh.dvs.open.min & dvs_total < -params.thresh.dvs.total.min;

for i=1:2

up_dvs_{i}=thresholdCondition(calculations.indicators{i}.lower.dvs_close,params.thresh.dvs.close,1) & thresholdCondition(calculations.indicators{i}.lower.dvs_total,params.thresh.dvs.total,1) & thresholdCondition(calculations.indicators{i}.lower.dvs_open,params.thresh.dvs.open,1);
dn_dvs_{i}=thresholdCondition(calculations.indicators{i}.lower.dvs_close,params.thresh.dvs.close,0) & thresholdCondition(calculations.indicators{i}.lower.dvs_total,params.thresh.dvs.total,0) & thresholdCondition(calculations.indicators{i}.lower.dvs_open,params.thresh.dvs.open,0);
end

up_dvs=up_dvs_{1} | up_dvs_{2};
dn_dvs=dn_dvs_{1} | dn_dvs_{2};

debug.indicatorsNames={'CloseFromUpperLevelPercent','avs{1}','rvs{1}','lxupp','lxdnp',... %1,','2,','3,','4,','5 reference to the condition 1,','2(4),','2(4),','3,','4,','
                  'dcs_fight','dsma5','ddsma5',... %6,','7,','8
                  'dvs_close','dvs_close',...  %9,','10
                  'dvs_total','dvs_total',...%11,','12
                  'dvs_open',' dvs_open',...%13,','14
                  'CloseFromLowerLevelPercent',... %15,'
                  'OpenFromUpperLevelPercent','HighFromUpperLevelPercent',...
                  'OpenFromLowerLevelPercent','LowFromLowerLevelPercent',...
                  'nextLowerLevelFromClose','nextUpperLevelFromClose',...
                  'BullBearCandleDiff'};

debug.indicators=[calculations.indicators{1}.lower.CloseFromUpperLevelPercent,avs{1},rvs{1},lxupp,lxdnp... %1,2,3,4,5 reference to the condition 1,2(4),2(4),3,4,
                  calculations.indicators{1}.lower.dcs_fight,calculations.indicators{1}.lower.dsma5,calculations.indicators{1}.lower.ddsma5,... %6,7,8
                  calculations.indicators{1}.lower.dvs_close,calculations.indicators{2}.lower.dvs_close,...  %9,10
                  calculations.indicators{1}.lower.dvs_total,calculations.indicators{2}.lower.dvs_total,...%11,12
                  calculations.indicators{1}.lower.dvs_open, calculations.indicators{2}.lower.dvs_open,...%13,14
                  calculations.indicators{1}.lower.CloseFromLowerLevelPercent,... %15
                  calculations.indicators{1}.lower.OpenFromUpperLevelPercent,calculations.indicators{1}.lower.HighFromUpperLevelPercent,...
                  calculations.indicators{1}.lower.OpenFromLowerLevelPercent,calculations.indicators{1}.lower.LowFromLowerLevelPercent,...
                  calculations.minDisProfileClose.mindislvl{1},calculations.minDisProfileClose.mindislvl{2},...
                  calculations.indicators{1}.lower.BullBearCandleDiff];
                
% debug.strategyIndicators{1,1}=[1,2,3,4,7,8,   9,10,11,12,13,14]; %upward
% debug.strategyIndicators{1,2}=[20,4,5,10,24,22,27,30]; 
% debug.strategyIndicators{2,1}=[1,6,7,8,9,10,11,21,29]; %upward
% debug.strategyIndicators{2,2}=[20,12,13,14,15,16,9,22,30];
% debug.strategyIndicators{3,1}=[1,6,17,8,19,10,11,29];  %upward
% debug.strategyIndicators{3,2}=[20,12,18,14,19,15,16,30];

%% more stop related

upNextLevelIsReaching= abs(calculations.indicators{1}.lower.HighFromUpperLevelPercent)<params.thresh.maxLastLvlByPercent;
dnNextLevelIsReaching= abs(calculations.indicators{1}.lower.LowFromLowerLevelPercent)<params.thresh.maxLastLvlByPercent;

upPrevLevelIsReached= abs(calculations.indicators{1}.lower.HighFromLowerLevelPercent)<params.thresh.maxLastLvlByPercent;
dnPrevLevelIsReached= abs(calculations.indicators{1}.lower.LowFromUpperLevelPercent)<params.thresh.maxLastLvlByPercent;

ddsmagettingsmaller=thresholdCondition(calculations.indicators{1}.lower.ddsma5,params.thresh.ddsma5,3);
ddsmagettinglarger=thresholdCondition(calculations.indicators{1}.lower.ddsma5,params.thresh.ddsma5,2);

%%


debug.AllConditionsnames={ 'goodnextlevel_up_farway', 'upcond_break', 'lxups,',... %1', '2', '3
      'dncond_break', 'lxdns,',... %4', '5
      'llp', 'fightup{1}', 'candle_up', 'vsgood{1}', 'dsma5low', 'ddsma5high,',...%6', '7', '8', '9', '10', '11
      'hhp', 'fightdn{1}', '~candle_up', 'dsma5high', 'ddsma5low,',... %12', '13', '14', '15', '16
      'fightup{2}', 'fightdn{2}', 'vsgood{2},',...%17', '18', '19
      'goodnextlevel_dn_farway,',... %20
      'up_dvs', 'dn_dvs,',...%21', '22
      'dsmasettlinghigh', 'dsmasettlinglow,',... %23', '24
      'BullishCandles', 'BearishCandles,',...   %25', '26
      'notbounceup', 'notbouncedn,',... %27', '28
      'lowerThanBBupper', 'higherThanBBlower ',... %29,30
      'fightup_all','fightdn_all',...               %31,32
      'goodlastlevel_up_bounce','goodlastlevel_dn_bounce',... %33,34
      'upReacingorReachedLevel','dnReachingorReachedLevel',... %35,36
       'ddsmagettingsmaller','ddsmagettinglarger' %,37,38
      };
 
debug.AllConditions=([goodnextlevel_up_farway,upcond_break,lxups,... %1,2,3
     dncond_break,lxdns,... %4,5
     llp,fightup{1},candle_up,vsgood{1},dsma5low,ddsma5high,...%6,7,8,9,10,11
     hhp,fightdn{1},~candle_up,dsma5high,ddsma5low,... %12,13,14,15,16
     fightup{2},fightdn{2},vsgood{2},...%17,18,19
     goodnextlevel_dn_farway,... %20
     up_dvs,dn_dvs,...%21,22
     dsmasettlinghigh,dsmasettlinglow,... %23,24
     BullishCandles,BearishCandles,...   %25,26
     notbounceup,notbouncedn,... %27,28
     lowerThanBBupper,higherThanBBlower,... %29,30
     fightup{1}|fightup{2},fightdn{1}|fightdn{2},...%31,32
     goodlastlevel_up_bounce,goodlastlevel_dn_bounce,... %33,34
     (upNextLevelIsReaching|upPrevLevelIsReached),(dnNextLevelIsReaching|dnPrevLevelIsReached),... %35,36
     ddsmagettingsmaller,ddsmagettinglarger %,37,38
     ]); 
   
     
%      
% cond11=[1,2,3,11,23,21,28,29]; %upward
% cond12=[20,4,5,10,24,22,27,30]; 
% cond21=[1,6,7,8,9,10,11,21,25,29]; %upward
% cond22=[20,12,13,14,15,16,9,22,26,30];
% cond31=[1,6,17,8,19,10,11,25,29];  %upward
% cond32=[20,12,18,14,19,15,16,26,30];

     
debug.DirectionCondition{1,1}=[1 ,2 ,3 ,15,11,23,21,28,29]; %upward
debug.DirectionCondition{1,2}=[20,4 ,5 ,10,16,24,22,27,30]; 
debug.DirectionCondition{2,1}=[1,6,31,8,9,10,11,21,29,33]; %upward
debug.DirectionCondition{2,2}=[20,12,32,14,15,16,9,22,30,34];
%debug.DirectionCondition{3,1}=[1,6,17,8,19,10,11,29];  %upward
%debug.DirectionCondition{3,2}=[20,12,18,14,19,15,16,30];

% calculations.DirectionPrediction{1}.Condition(:,1)=min(debug.AllConditions(:,debug.DirectionCondition{1,1}),[],2);%(upcond_break_goodnextlevel & upcond_break & lxups)& dsma5high & ddsma5high;
% calculations.DirectionPrediction{2}.Condition(:,1)=min(debug.AllConditions(:,debug.DirectionCondition{1,2}),[],2);%((dncond_break_goodnextlevel & dncond_break & lxdns)& dsma5low & ddsma5low;
% calculations.DirectionPrediction{1}.Condition(:,2)=min(debug.AllConditions(:,debug.DirectionCondition{2,1}),[],2);%(llp &  fightup{1} & candle_up & vsgood{1} & dsma5low  & ddsma5high;
% calculations.DirectionPrediction{2}.Condition(:,2)=min(debug.AllConditions(:,debug.DirectionCondition{2,2}),[],2);%(hhp & fightdn{1} & ~candle_up & vsgood{1} & dsma5high  & ddsma5low;
% calculations.DirectionPrediction{1}.Condition(:,3)=min(debug.AllConditions(:,debug.DirectionCondition{3,1}),[],2);%(llp & fightup{2} & candle_up& vsgood{2} & dsma5low  & ddsma5high;
% calculations.DirectionPrediction{2}.Condition(:,3)=min(debug.AllConditions(:,debug.DirectionCondition{3,2}),[],2);%(hhp & fightdn{2} & ~candle_up& vsgood{2} & dsma5high & ddsma5low;


for i=1:size(debug.DirectionCondition,1)
    for j=1:size(debug.DirectionCondition,2)
        calculations.DirectionPrediction{j}.Condition(:,i)=min(debug.AllConditions(:,debug.DirectionCondition{i,j}),[],2);
    end
end


%;ticenter=toc
catch exception
   getReport(exception,'extended','hyperlinks','off') 
    
end
%;ticscond=toc

%% stop conditions


% debug.AllStopConditionsnames={'upNextLevelIsReaching','dnNextLevelIsReaching',...
%     'ddsmagettingsmaller','ddsmagettinglarger',...
%     'candle_up','~candle_up'};
%  
% debug.AllStopConditions=([upNextLevelIsReaching,dnNextLevelIsReaching,...
%     ddsmagettingsmaller,ddsmagettinglarger,...
%     candle_up,~candle_up
%     ]);
        
debug.StopCondition{1,1}=[35,37,8]; %upward
debug.StopCondition{1,2}=[36,38,14]; 

for i=1:size(debug.StopCondition,1)
    for j=1:size(debug.StopCondition,2)
        calculations.StopPrediction{j}.Condition(:,i)=min(debug.AllConditions(:,debug.StopCondition{i,j}),[],2);
    end
end


%;tic
%% conditiondetails

%% automate conditions, and signal types
condlen=size(calculations.DirectionPrediction{1}.Condition,2);
dircmul=(0:condlen-1)';
dircmul=pow2(dircmul);
denabled=params.DirectionPredictionEnabled(1:numel(dircmul));
dircmul=dircmul.*denabled;

condlen=size(calculations.StopPrediction{1}.Condition,2);
stopcmul=(0:condlen-1)';
stopcmul=pow2(stopcmul);
denabled=params.StopPredictionEnabled(1:numel(stopcmul));
stopcmul=stopcmul.*denabled;
%;ticscmu=toc


%;tic
%% Process conditions
% for now, I am going to cheat and find the maximum/minimum in the next x minutes
try
    
    %;tic;
calculations.DirectionPrediction{1}.final=calculations.DirectionPrediction{1}.Condition*dircmul;
calculations.DirectionPrediction{2}.final=calculations.DirectionPrediction{2}.Condition*dircmul;

calculations.indicators{1}.eval.pbto=(calculations.DirectionPrediction{1}.final>0)  .*params.TimeTables.Day.High;% .* lxups;
calculations.indicators{1}.eval.psto=(calculations.DirectionPrediction{2}.final>0) .*params.TimeTables.Day.Low;% lxdns;

calculations.StopPrediction{1}.final=calculations.StopPrediction{1}.Condition*stopcmul;
calculations.StopPrediction{2}.final=calculations.StopPrediction{2}.Condition*stopcmul;

calculations.indicators{1}.eval.pstc=(calculations.StopPrediction{1}.final>0)  .*calculations.minDisProfileClose.mindislvl{2}; %next upper level from close
calculations.indicators{1}.eval.pbtc=(calculations.StopPrediction{2}.final>0) .*calculations.minDisProfileClose.mindislvl{1}; % next lower level from lcose


%;ticexit=toc

catch exception
   getReport(exception,'extended','hyperlinks','off') 
    
end

%% non-causal buysell signals
tradeGroundTruth_signals_(1)=0;
calculations.indicators{1}.eval.tradeGroundTruth_signals=tradeGroundTruth_signals_;%eros(size(params.TimeTables.Minute.Close));

%commas=repmat(',',size(params.TimeTables.Minute.Date,1),1);
%[datestr(params.TimeTables.Minute.Date),commas,num2str(calculations.DirectionPrediction{1}.final),commas,num2str(calculations.DirectionPrediction{2}.final),num2str(lxdns), num2str(lxups),num2str(calculations.indicators{1}.lower.dsma5),commas,num2str(calculations.minDisProfileClose.mindis{1}),num2str(calculations.minDisProfileClose.mindis{2}),num2str(calculations.indicators{1}.lower.CloseFromUpperLevelPercent),num2str(debug.AllConditions(:,cond11))]
%[datestr(params.TimeTables.Minute.Date),num2str(dcs{1}.fight),num2str(dcs{2}.fight),num2str(avs{1}),num2str(avs{2}),num2str(rvs{1}),num2str(rvs{2}),num2str(calculations.indicators{1}.lower.dsma5),num2str(calculations.indicators{1}.lower.ddsma5),num2str(dvs{1}.close),num2str(dvs{2}.close),num2str(dvs{1}.open),num2str(dvs{2}.open),num2str(dvs{1}.total),num2str(dvs{2}.total)]

%;ticexit=toc
catch exception
   getReport(exception,'extended','hyperlinks','off') 
    
end
end

