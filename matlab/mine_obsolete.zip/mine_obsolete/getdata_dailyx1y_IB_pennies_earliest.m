baseclientid=31;

basedir='Z:\My files\Project trading\traderdata\data_other\IB\';

contracts_pennies;

asmp1 = NET.addAssembly(('Z:\My files\Project trading\repo\matlab\mine\bin\release\CSharpAPI.dll'));
asmp2 = NET.addAssembly(('Z:\My files\Project trading\repo\matlab\mine\bin\release\IBBackEnd.dll'));
asmp3 = NET.addAssembly(('Z:\My files\Project trading\repo\matlab\mine\bin\release\IBControlDefinition.dll'));

asm1 = NET.addAssembly('System.IO');
asm2 = NET.addAssembly('System.Runtime.Serialization');

import System.IO.*;
import MHA.*;
import MHA.IBControlDefinition.*;
import MHA.IBControlDefinition.Tools.*;
import MHA.IBControlDefinition.Tools.Contracts.*;
import IBApi.*;

%% constants

version='ib';
currentTicker = 1;

%% init

signal=EReaderMonitorSignal;
ibClient=IBClient(signal);
ibWrapper=IBWrapper(ibClient,signal);

%% set handles

%all standard handles are available to signal matlab as well

events.eventhandlerError= addlistener(ibWrapper,'HandledError',@HandledErrorFcn);

events.eventhandlerTick = addlistener(ibWrapper,'HandledTickPrice',@HandledTickFcn);
events.eventhandlerOrderStatus = addlistener(ibWrapper,'HandledOrderStatus',@HandledOrderStatusFcn);
events.eventhandlerPositions= addlistener(ibWrapper,'HandledPosition',@HandledPositionFcn);

events.eventhandlerHistoricalDataUpdate= addlistener(ibWrapper,'HandledHistoricalDataUpdate',@HandledHistoricalDataUpdateFcn);
events.eventhandlerHistoricalData= addlistener(ibWrapper,'HandledHistoricalData',@HandledHistoricalDataFcn);
events.eventhandlerHistoricalEndData= addlistener(ibWrapper,'HandledHistoricalDataEnd',@HandledHistoricalDataEnd_getarray_Fcn);


%% connect
port=[4001 4002 7497 7496];
ibClient.ClientId=floor(rand()*10)+baseclientid;

isconnected=ibConnect(ibWrapper,port);

if (isconnected)
    
    %ibClient.ClientSocket.reqMarketDataType(3); %1 for realtime 2 frozen, 5 delayd frozen, 3 delayed
    pause(1);
    
    %% setup
    
    duration = "1 Y"; % //S,D,W,M,Y
    barsize = "1 day";
    
    keepuptodate = false;
    whattoshow="TRADES";
    
    RTHonly=0; % during market time
    
    latestday=90;
    beginning=1;
    
    if (datetime().Hour>=20) %after 8 o'clock, get today's data as well.
        beginning=0;
    end
    for ds=beginning:(latestday-1)
        date_=datetime()-days(ds);
        if (isbusday(date_))
            date0=datestr(date_,'yyyy-mm-dd');
            disp(date0);
            %date0=[num2str(year_) '-' num2str(months_,'%02.f') '-' num2str(days_,'%02.f')]
            dateib=datestr(datetime()-days(ds),'yyyymmdd');
            %dateib=[num2str(year_) num2str(months_,'%02.f') num2str(days_,'%02.f')];
            enddatetime = [dateib ' 22:00:00'] %//empty for most recent when keepuptodate=true... sample 20200615 13:22:00, if goal is to get only historical data, then use end of day time, and keepuptodate=false
            
            for si=1:numel(contracts)
                try
                    contract=  contracts{si};
                    disp(contract.Symbol);
                    ibcontract=getGenericContract(contract);
                    filename=[basedir filefriendlysymbol(contract.FileSymbol) '\' filefriendlysymbol(contract.FileSymbol) ' dailyx1y ' date0 '.mat'];
                    
                    if (~exist(filename))
                        if (~exist([basedir filefriendlysymbol(contract.FileSymbol) '\' ]))
                            mkdir([basedir filefriendlysymbol(contract.FileSymbol) '\' ]);
                        end
                        %% get historical data
                        
                        %and put it in some timetable
                        td=[];%genNanTimeTable(datetime([date0 ' 09:30:00'])+minutes((0:389)'));
                        timetablename{1}='td';
                        interruptisdone=0;
                        hasmajorerror=0;
                        if (ibClient.ClientSocket.IsConnected()==0)
                            ibClient.ClientId=floor(rand()*10)+baseclientid;
                            isconnected=ibConnect(ibWrapper,port);
                            currentTicker=1;
                        end
                        if (ibClient.ClientSocket.IsConnected()==1)
                            % ibClient.ClientSocket.reqMarketDataType(3); %1 for realtime 2 frozen, 5 delayd frozen, 3 delayed
                            
                            disp('ib clean up...');
                            pause(.1);
                            ibWrapper.CleanUpHistoricalData();
                            ibWrapper.CleanUpHistoricalDataEnd(); % CleanUpHistoricalDataEnd instead, dll was not developed yet at the time
                            pause(.1);
                            disp('requesting data...');
                            
                            reqid = ibWrapper.HISTORICAL_ID_BASE + currentTicker;
                            currentTicker=currentTicker+1;
                            
                            
                            
                            ibWrapper.reqHistoricalData(reqid, ibcontract, enddatetime, duration, barsize,whattoshow , RTHonly, 1, keepuptodate, NET.createArray('IBApi.TagValue',0));
                            disp('waiting for ibwrapper...');
                            interruptisdone=waitUnlessError(ibWrapper,20);
                            
                            disp('waiting for interrupt...');
                            d0=datetime();
                            while(interruptisdone==0)
                                pause(.1);
                                d1=datetime();
                                if (seconds(d1-d0)>10)
                                    break
                                end
                            end
                            pause(0.5);
                            if (ibWrapper.RequestEnded==0 && ibWrapper.HistoricalDataMessages.Count>0)
                                disp('no interrupt, but there is data...');
                                HandledHistoricalDataEnd_getarray_Fcn(ibWrapper,0);
                            end
                            
                            disp(['grabbed all tmsize=' num2str(size(td,1))]);
                            if (~isempty(td))
                                save(filename,'td','version');
                            end
                            
                        end
                        
                        if (currentTicker>48)
                            ibWrapper.Disconnect();
                            pause(2);
                        end
                        
                    else
                        disp('data already exists.');
                    end
                    
                    if (datetime()>datetime('04:00:00') && datetime()<datetime('04:30:00'))
                        break;
                    end
                catch exception
                    getReport(exception,'extended','hyperlinks','on')
                end
            end
        end
    end
    %% disconnect
    
    ibWrapper.Disconnect();
else
    disp('did not connect');
end


ibClient.ClientSocket.IsConnected()


