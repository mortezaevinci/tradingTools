% HOT_BY_PRICE
% HOT_BY_VOLUME
% TOP_TRADE_RATE
% TO_VOLUME_RATE


% 
% priceAbove	5
% volumeAbove 100000
% AFTERHRSCHANGEPERC 2
% marketCapAbove1e6	200
% 
% 
% afterHoursChangePercAbove
% changePercAbove
% changePercBelow
% 
% scancode doesn't matter, just add something that shows all
% Maybe
% ALL_SYMBOLS_ASC
% MOST_ACTIVE
% 
% STK
% ALL
% STK.US.MAJOR

%parameters

ibscansize=100;

clear tv;
%     t1 = IBApi.TagValue("usdMarketCapAbove", "10000");
%     t2 = IBApi.TagValue("optVolumeAbove", "0");
%     t3 = IBApi.TagValue("avgVolumeAbove", "1000000");
    tv{1} = IBApi.TagValue("marketCapAbove1e6", "20");
    tv{2} = IBApi.TagValue("volumeAbove", "50000");
    tv{3} = IBApi.TagValue("priceAbove", "0.8");
    tv{3} = IBApi.TagValue("priceBelow", "25");
    
    tvs = NET.createGeneric('System.Collections.Generic.List',{'IBApi.TagValue'},numel(tv));
    for i=1:numel(tv)
    tvs.Add(tv{i});
    end
    
 tvsscanner=NET.createGeneric('System.Collections.Generic.List',{'IBApi.TagValue'},0);
            
 subscription = IBApi.ScannerSubscription;
 subscription.ScanCode = 'HOT_BY_VOLUME'; %HOT_BY_VOLUME
 subscription.Instrument = 'STK';
 subscription.LocationCode = 'STK.US.MAJOR';
 subscription.StockTypeFilter = 'ALL';
 subscription.NumberOfRows = ibscansize;    
