%for now, this would only work for the last day of data, because of the way
%last day and last month are found.

%************this will probably not work at the first day of the month...
%need to find the last month, last day better.. maybe won't even work at
%the beginnign of thre day

%can possibly update tm data in real-time here, and show

close all



 global SYMBOLDONETODAY;
clearvars -except SYMBOLDONETODAY parf_loop_calculations;
%basedate='2020-06-02'; %set to last saturday, where data are gathered

%looperparams_realtime;
%run('config\looperparams_backtestall.m');
run('config\looperparams_realtime.m');
%run('config\looperparams_study.m');

%run('config\commonticks_test.m');
%run('config\commonticks_realtime.m');
%run('config\commonticks_patternrec_t1.m');
%run('config\commonticks_patternrec_t1.m');
run('config\commonticks_patternrec_t9_ID3.m');

%main params
%run('config\mainparams_backtest_test_t7.m');
run('config\mainparams_backtest_test_t9_STUDY_ID3.m');

%%bypass

bypasssymbols={};
%bypasssymbols={'AAL','AMZN','TSLA','AAPL','NFLX','NVDA','BA','SPY'};
%bypasssymbols={'AAL','AMZN','TSLA','ROKU','BYND','NVDA','BA','SPY'};
%bypasssymbols={'WMT','NFLX'};
%bypasssymbols={'TTOO','GNUS','BHTG','CIDM','FRSX','GNC','PHIO','RUHN'};
%bypasssymbols={'SPY'};

%bypasssymbols={'SHOP','SPY'};

%% add daily view


 %run('config\looperparams_realtime_daily.m');
% if (~isempty(bypasssymbols))
% looperParams.symbols=bypasssymbols;
% end
% backtest_breakout_t8;
% 
%  
% run('config\looperparams_realtime.m');

looperParams.getdatainit=1;
%% add daily view


 if (looperParams.updaterealtime==1 || looperParams.getalldatainrealtime==1)
     backtest_breakout_t7_workeron;
 end

if (~isempty(bypasssymbols))
looperParams.symbols=bypasssymbols;
end


%;tic;
backtest_breakout_t8;
%;ticmain=toc

try
 backtest_breakout_t7_workeroff;
catch
    
end