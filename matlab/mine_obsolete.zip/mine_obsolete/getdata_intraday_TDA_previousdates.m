%collect 1min data every weekend before they become unavailable
dtnow=datetime();
if (hour(dtnow)>=16)
 lastfullday=(day(dtnow));
else 
lastfullday=(day(dtnow)-(1));
end
days_=lastfullday:-1:1;
cmonth=month(dtnow);

if (cmonth==1)
   months_=1; %doesn't really matter.. the data must have been taken before
else
  months_=cmonth:-1:(cmonth-1);
end

year_=year(dtnow);

symbols_tda;

%% bypass
   symbols={'AAPL'};
   months_=7;
   days_=2;

%% run

basedir='Z:\My files\Project trading\traderdata\data\';

for j=months_
for i=days_ 
    
date1=[num2str(year_) '-' num2str(j,'%02.f') '-' num2str(i,'%02.f')]
date2=datestr(datetime(date1)+days(1),'yyyy-mm-dd');

 getdata_intraday_TDA_func(basedir,symbols,date1,date2);

end
end
%mm=table2timetable(tm)