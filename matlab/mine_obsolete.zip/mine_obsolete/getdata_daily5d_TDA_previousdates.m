%collect 1min data every weekend before they become unavailable
dtnow=datetime();
if (hour(dtnow)>=16)
 lastfullday=(day(dtnow));
else 
lastfullday=(day(dtnow)-(1));
end
days_=lastfullday:-1:1;
cmonth=month(dtnow);

if (cmonth==1)
   months_=1; %doesn't really matter.. the data must have been taken before
else
  months_=cmonth:-1:(cmonth-1);
end

year_=year(dtnow);

symbols_tda;

apikey='9DA0ZYLF59IGMA6TDXEGKFXVEKAC3TWS';
periodType='month';
period=1;
frequencyType='daily';
frequency=1;
disabled=0;

for j=months_
for i=days_

    date0=[num2str(year_) '-' num2str(j,'%02.f') '-' num2str(i,'%02.f')];
if (isbusday(date0))
getdata_daily5d_TDA_func(symbols,date0);
end
end
end
%mm=table2timetable(tm)