%for now, this would only work for the last day of data, because of the way
%last day and last month are found.

%************this will probably not work at the first day of the month...
%need to find the last month, last day better.. maybe won't even work at
%the beginnign of thre day

%can possibly update tm data in real-time here, and show

close all

global SYMBOLDONETODAY;
clearvars -except SYMBOLDONETODAY parf;

%looperparams_realtime;
%run('config\looperparams_backtestall.m');
%run('config\looperparams_realtime_study_return');
run('config\looperparams_realtime_study_extended');

%run('config\commonticks_test.m');
%run('config\commonticks_realtime.m');
run('config\commonticks_patternrec_t1');
%%bypass

%looperParams.symbols={'AAL','AMZN','TSLA','AAPL','NFLX','NVDA','BA','SPY'};
%looperParams.symbols={'AAL','AMZN','TSLA','ROKU','BYND','NVDA','BA','SPY'};
%looperParams.symbols={'AAL'};
%main params
run('config\mainparams_backtest_test_t7_STUDY');
%run('config\mainparams_backtest_test_t7_loose.m');

if (looperParams.updaterealtime==1 || looperParams.getalldatainrealtime==1)
    backtest_breakout_t7_workeron;
end

symbols_=looperParams.symbols;

symbolsections=[1:16:numel(symbols_)];
if (symbolsections(end)~=numel(symbols_)+1)
	symbolsections=[symbolsections numel(symbols_)+1];
end

for symbi=1:(numel(symbolsections)-1)
    close all
looperParams.symbols=symbols_(symbolsections(symbi):(symbolsections(symbi+1)-1));
backtest_breakout_t7;

end

try
 backtest_breakout_t7_workeroff;
catch
    
end