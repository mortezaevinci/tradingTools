%% init dates

%collect 1min data every weekend before they become unavailable
dtnow=datetime();
if (hour(dtnow)>=16)
 lastfullday=(day(dtnow));
else 
lastfullday=(day(dtnow)-(1));
end
days_=31:-1:1;%lastfullday:-1:1;
cmonth=month(dtnow);

if (cmonth==1)
   months_=1; %doesn't really matter.. the data must have been taken before
else
  months_=cmonth:-1:(cmonth-1);
end

year_=year(dtnow);


%% loop through contracts

contracts_yahoo;
s1=contracts;
contracts_tda;
s2=contracts;

allcontracts=unique([s1,s2]);

%allcontracts={genContract('AAL')};
ns=numel(allcontracts);
for si=1:ns

    try
    
    contract=allcontracts(si);
  %  symbol=symbol{1}
    
%% init volumeproifle
minutesIndex=(1:390)';

DataCount=zeros(size(minutesIndex));
Volume=DataCount;
VolumeBuzzProfile=table(minutesIndex,Volume);
    
%% loop through dates

for j=months_
for i=days_
    try
   date_=[num2str(year_) '-' num2str(j,'%02.f') '-' num2str(i,'%02.f')];

minutedatafilename=['Z:\My files\Project trading\traderdata\data\' filefriendlysymbol(contract.FileSymbol) ' minute ' date_ '.mat'];
if (exist(minutedatafilename))
load(minutedatafilename);

if (~isempty(tm))

dt=datetime(tm.Date);
minutesIndex=minutes(dt-dt(1))+1;
Volume=tm.Volume;

cum1=ones(size(minutesIndex));
cum1(isnan(Volume))=0;

DataCount(minutesIndex)=DataCount(minutesIndex)+cum1;

Volume(isnan(Volume))=0;

VolumeBuzzProfile(minutesIndex,:).Volume=VolumeBuzzProfile(minutesIndex,:).Volume+Volume;

end
end
    catch
    end
end
end

VolumeBuzzProfile.Volume=VolumeBuzzProfile.Volume./DataCount;

vfilename=['Z:\My files\Project trading\traderdata\data_processed\volumeprofile\' filefriendlysymbol(contract.FileSymbol) ' volumebuzzprofile.mat'];
save(vfilename,'VolumeBuzzProfile');

    catch exception
     getReport(exception,'extended','hyperlinks','off') 
    
end

end