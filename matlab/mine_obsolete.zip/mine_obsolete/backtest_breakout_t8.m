5%for now, this would only work for the last day of data, because of the way
%last day and last month are found.

%************this will probably not work at the first day of the month...
%need to find the last month, last day better.. maybe won't even work at
%the beginnign of thre day

%can possibly update tm data in real-time here, and show

try

%% prepare 
somethingtodo=datetime('2019-01-01');
 ncommon=numel(commonticks);
nsymbols=numel(looperParams.symbols);

calculations=cell(1,nsymbols);
result=cell(1,nsymbols);
params=cell(1,nsymbols);


 global KEY_IS_PRESSED;
KEY_IS_PRESSED = 0;

WarnWave = [sin(1:.3:300), sin(1:.5:300)];%, sin(1:.4:300)];
Audio = audioplayer(WarnWave, 22050);
if (looperParams.graph.show>0)
   
if (looperParams.graph.isfull)
for si=1:nsymbols
bbFig{si}=figure('units','normalized','outerposition',looperParams.graph.figureSize);
panel{si}=uipanel('Title',looperParams.symbols{si},'Position',[0 0 1 1]);
set(bbFig{si}, 'KeyPressFcn', @myKeyPressFcn)
end
else
bbFig{1}=figure('units','normalized','outerposition',looperParams.graph.figureSize);
set(bbFig{1}, 'KeyPressFcn', @myKeyPressFcn)

%bbFigspecial=figure('units','normalized','outerposition',looperParams.graph.figureSize);
%panelspecial=uipanel('Title','Selected','Position',[0 0 1 1]);
%set(bbFigspecial, 'KeyPressFcn', @myKeyPressFcn);
end

end
KEY_IS_PRESSED = 0;

sir=min(2,nsymbols);
sis=ceil(nsymbols/sir);
w=1;
h=1;

crumb=[];
rq=[];


for si=1:nsymbols
   
    mainticks{si}.params=tempsymbol.params;
    mainticks{si}.params.symbol=looperParams.symbols{si};
    mainticks{si}.params.si=si;
end

%parpool('local');


for si=1:nsymbols   
    lastclose{si}=-1;
     lastshowlimit{si}=-1;
     lastdatasize{si}=-1;
    sc=floor((si-1)/sir);
    sr=(si-1)-sc*sir;
    sr=-si+(sc+1)*sir;
    if (looperParams.graph.isfull)
        
    else
        if (looperParams.graph.show>0)
           panelPosition{si}=[w*sc/sis h*sr/sir w*1/sis h/sir];
           panel{si}=uipanel('Title',[looperParams.symbols{si} '(' (char('a'+si-1)) ')'],'Position',panelPosition{si});
        end
    end
end

%threadPlot_special = parallel.pool.DataQueue;
%threadPlot_special.afterEach(@(x) graphStrategy_full_t5(panelspecial,looperParams,x{1},x{2},x{3},1)); 
threadPlot_single = parallel.pool.DataQueue;
threadPlot_single.afterEach(@(x) graphStrategy_full_t7(x{2}.layout,x{2},x{3},x{4},x(5))); 
threadPlot = parallel.pool.DataQueue;
threadPlot.afterEach(@(x) graphStrategy_t7(x{2}.layout,x{2},x{3},x{4},x(5)));

%pause(2); %graphs need to init first

%init graph
disp('initializing...');
for  si=1:nsymbols
disp(mainticks{si}.params.symbol);

 
if (looperParams.net.use==1)
    mainticks{si}.params.net.use=1;
    
    netfilename=['Z:\My files\Project trading\traderdata\nets\netP1 ' filefriendlysymbol(mainticks{si}.params.symbol) ' ID' num2str(looperParams.net.setupId) '.mat'];
    if (exist(netfilename))
        load(netfilename);
        mainticks{si}.params.net.netP1=netP1;  
    end
end

if (looperParams.graph.show==2 || (looperParams.graph.show==1 && somethingtodo))
%graphStrategy_t2(bbFig,panel{si},mainticks{si}.params,calculations,result);

% if (numel(KEY_IS_PRESSED)==1 && KEY_IS_PRESSED==('a'+si-1) && ~looperParams.runOnce)
%    % graphStrategy_full_t5(panelspecial,mainticks{si}.params,mainticks{si}.calculations,result{si});
% else
if (looperParams.graph.isfull)
mainticks{si}.params.layout=graphStrategy_full_t7_init(panel{si},looperParams,mainticks{si}.params,result{si});
else
mainticks{si}.params.layout=graphStrategy_t7_init(panel{si},looperParams,mainticks{si}.params,result{si});

end
%end
end
end


disp('ready to go...');
if (looperParams.continueAfterInit==0)
pause;
end

global initgetdatadone;


%parfeval(@initGetdata_t8,3,looperParams,mainticks,commonticks);
[sucess,mainticks,commonticks]=initGetdata_t8(looperParams,mainticks,commonticks);
    
    selectedchannel='z';
selectedchannelupdated=1;
%% keep loop

while(initgetdatadone==0)
pause(.5);
end


disp('Go!');

%% evaluate symbols
lastalert=datetime();


 looperParams.backupShowLimit=looperParams.graph.showlimit;

while(1)
    
    %disp(['data loop state is ' parf_loop_calculations.State]);
try
    if (~isempty(KEY_IS_PRESSED))
    if (KEY_IS_PRESSED(1)=='0')
        break;
    end
    end
    
%% loop

 %% evaluate commonticks
 %;tic

    for si2=1:ncommon
        try
        if (looperParams.updaterealtime==1)
        commonticks{si2}.params=updaterealtimeByFile(commonticks{si2}.params);
        else
        commonticks{si2}.params=strategy_getdata(looperParams,commonticks{si2}.params);
        end

        
        commonticks{si2}.calculations=strategy_breakout_t8(looperParams,commonticks{si2}.params,[]);
        catch exception
   getReport(exception,'extended','hyperlinks','off') 
    
end
    end
 %;ticbcommon=toc

%parfor  (si=1:nsymbols,useparfor)
for si=1:nsymbols
    try
    if (~isempty(KEY_IS_PRESSED))
    if (KEY_IS_PRESSED(1)=='0')
        break;
    end
    end

    


if (~isempty(KEY_IS_PRESSED))
   if (strcmp(KEY_IS_PRESSED,'leftarrow'))
       KEY_IS_PRESSED='';
       looperParams.graph.showlimit=looperParams.graph.showlimit+looperParams.graph.showlimitstep;
       if (looperParams.graph.showlimit>looperParams.graph.showlimitmax)
           looperParams.graph.showlimit=looperParams.graph.showlimitmax;
       end
   end
   
   if (strcmp(KEY_IS_PRESSED,'rightarrow'))
       KEY_IS_PRESSED='';
       looperParams.graph.showlimit=looperParams.graph.showlimit-looperParams.graph.showlimitstep;
       if (looperParams.graph.showlimit<0)
           looperParams.graph.showlimit=0;
       end
   end
end

    
if (numel(KEY_IS_PRESSED)==1 && KEY_IS_PRESSED>='a' && KEY_IS_PRESSED<'a'+nsymbols)
    selectedchannel=KEY_IS_PRESSED;
    KEY_IS_PRESSED='';
    selectedchannelupdated=0;
end
if (numel(KEY_IS_PRESSED)==1 && KEY_IS_PRESSED=='z')
    selectedchannel='z';
    KEY_IS_PRESSED='';
    selectedchannelupdated=0;
end

if (selectedchannel=='z' && selectedchannelupdated==0)

   %show all again
   for jj=1:nsymbols
       panel{jj}.Position=panelPosition{jj};
      panel{jj}.Visible=true; 
   end
   selectedchannelupdated=1;
end

% one symbol is selected
if (selectedchannel=='a'+si-1  && selectedchannelupdated==0)
    for jj=1:nsymbols
     
      panel{jj}.Visible=false; 
    end
   selectedsi=selectedchannel-'a'+1;
   
   panel{selectedsi}.Position=[0 0 1 1];
   panel{selectedsi}.Visible=true;
      selectedchannelupdated=1;
end

if (selectedchannel~='a'+si-1  && selectedchannel~='z')
   continue; 
end




disp(mainticks{si}.params.symbol);

%% update real-time could be lower, if orb level was done a bit differently
%;tic
if (looperParams.updaterealtime==1)
    mainticks{si}.params=updaterealtimeByFile(mainticks{si}.params);
else
    mainticks{si}.params=strategy_getdata(looperParams,mainticks{si}.params);
end
%;ticbupdatedata=toc
    
if (looperParams.backStudyPoints>0)
   mainticks{si}.params.TimeTables.Minute=mainticks{si}.params.TimeTables.Minute(1:(390-looperParams.backStudyPoints),:); 
end

% don't do anything if, there is no new data
newdatasize=numel(mainticks{si}.params.TimeTables.Minute.Date);
newlastclose=mainticks{si}.params.TimeTables.Minute.Close(end);

if ((newlastclose==lastclose{si} && newdatasize==lastdatasize{si}) && lastshowlimit{si}==looperParams.graph.showlimit)
    drawnow;
    continue;
else
    lastshowlimit{si}=looperParams.graph.showlimit;
    lastclose{si}=newlastclose;
    lastdatasize{si}=newdatasize;
end

disp('Processing...');

try
%;tic
 %;disp('calculations');
if (mainticks{si}.params.doBookOnly==0)
    
if (looperParams.useBookLevels>0)
datestring=datestr(datetime(looperParams.date),'yyyy-mm-dd');
filename=['Z:\My files\Project trading\traderdata\book\' filefriendlysymbol(mainticks{si}.params.symbol) '_book_history ' datestring '.bn2'];
mainticks{si}.params.marketdata=getProcessedMarketdata2(filename,datestring);
if (~isempty(mainticks{si}.params.marketdata))
mainticks{si}.params.marketdata=marketbooklevels(mainticks{si}.params.marketdata);
end
end

[mainticks{si}.calculations,mainticks{si}.debug]=strategy_breakout_t8(looperParams,mainticks{si}.params,commonticks);




%calculations=fetchOutputs(parf);
 %;disp('results');
result{si}=signals_next5_t1(mainticks{si}.params,mainticks{si}.calculations);

%% results
somethingtodo=alertSignals(mainticks{si}.params,mainticks{si}.calculations);
end

catch exception
   getReport(exception,'extended','hyperlinks','off') 
end

%;ticbcalcsandres=toc

try

if (seconds(datetime()-somethingtodo)<60 && (seconds(datetime()-lastalert))>30)
play(Audio); 
lastalert=datetime();
end


disp(['algo return %' num2str(mainticks{si}.calculations.indicators{1}.eval.tradeStrategyBreakoutT8_return(end))]);

performanceMatrix{si}.conditionsTotal=evaluateConditions(mainticks{si}.params,mainticks{si}.calculations,mainticks{si}.debug);


catch exception
   getReport(exception,'extended','hyperlinks','off') 
end

try
%;tic
 %;disp('graph');
if (looperParams.graph.show==2 || (looperParams.graph.show==1 && somethingtodo))
%graphStrategy_t2(bbFig,panel{si},mainticks{si}.params,calculations,result);


if (looperParams.graph.isfull)

%send(threadPlot_single,{si,mainticks{si}.params,mainticks{si}.calculations,result{si}});
graphStrategy_full_t7(mainticks{si}.params.layout,looperParams,mainticks{si}.params,mainticks{si}.calculations,result{si});
else
%send(threadPlot,{si,mainticks{si}.params,mainticks{si}.calculations,result{si}});
graphStrategy_t7(mainticks{si}.params.layout,looperParams,mainticks{si}.params,mainticks{si}.calculations,result{si});
end


%drawnow;
%;ticbgraph=toc
end

catch exception
   getReport(exception,'extended','hyperlinks','off') 
end

catch exception
   getReport(exception,'extended','hyperlinks','off') 
end

end


if (looperParams.graph.saveFigures)
    disp('saving figures...');
    nfig=numel(bbFig);
    for i=1:nfig
        if (nfig==numel(looperParams.symbols))
           symname=looperParams.symbols{i};
        else
           symname=strjoin(looperParams.symbols);
        end
       
       saveas(bbFig{i},['Z:\My files\Project trading\traderdata\figures\fig_' filefriendlysymbol(symname) datestr(datetime(),"yy-mm-dd hh_MM_ss") '.svg']);
       savefig(bbFig{i},['Z:\My files\Project trading\traderdata\figures\fig_' filefriendlysymbol(symname) datestr(datetime(),"yy-mm-dd hh_MM_ss") '.fig']);
    end
end

if (looperParams.runOnce==1) 
    break;
end

if (looperParams.backStudyPoints>0)
    
    cntup=1;
        if (~isempty(KEY_IS_PRESSED))
    if (KEY_IS_PRESSED(1)>'0' && KEY_IS_PRESSED(1)<='9')
       cntup=KEY_IS_PRESSED(1)-'0';
    end
    end
    
looperParams.backStudyPoints=looperParams.backStudyPoints-cntup;
if (looperParams.backStudyPoints<=0)
    break;
end
pause(1);
end

catch exception
   getReport(exception,'extended','hyperlinks','off') 
    
end



end %while



catch exception
   getReport(exception,'extended','hyperlinks','off') 
    
end