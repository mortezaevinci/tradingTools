%% init dates

%collect 1min data every weekend before they become unavailable
dtnow=datetime();
if (hour(dtnow)>=16)
 lastfullday=(day(dtnow));
else 
lastfullday=(day(dtnow)-(1));
end
days_=31:-1:1;%lastfullday:-1:1;
cmonth=month(dtnow);

if (cmonth==1)
   months_=1; %doesn't really matter.. the data must have been taken before
else
  months_=cmonth:-1:(cmonth-1);
end

year_=year(dtnow);


%% loop through contracts

contracts_yahoo;
s1=contracts;
contracts_tda;
s2=contracts;

allcontracts=unique([s1,s2]);

%allcontracts={genContract('AAL')};
ns=numel(allcontracts);
for si=1:ns

    try
    
    contract=allcontracts(si);
   % symbol=symbol{1}
    
%% init volumeproifle
minutesIndex=(1:390)';

DataCount=zeros(size(minutesIndex));
Open=DataCount;
High=DataCount;
Low=DataCount;
Close=DataCount;
Volume=DataCount;
PriceActionProfile=table(minutesIndex,Open,High,Low,Close,Volume);
    
%% loop through dates

for j=months_
for i=days_
    try
   date_=[num2str(year_) '-' num2str(j,'%02.f') '-' num2str(i,'%02.f')];

minutedatafilename=['Z:\My files\Project trading\traderdata\data\' filefriendlysymbol(contract.FileSymbol) ' minute ' date_ '.mat'];
if (exist(minutedatafilename))
load(minutedatafilename);

if (~isempty(tm))

dt=datetime(tm.Date);
minutesIndex=minutes(dt-dt(1))+1;
Volume=tm.Volume;
Open=tm.Open;
Close=tm.Close;
Low=tm.Close;
High=tm.High;

cum1=ones(size(minutesIndex));
cum1(isnan(Volume) | isnan(Open) | isnan(Close))=0;

DataCount(minutesIndex)=DataCount(minutesIndex)+cum1;

Volume(cum1==0)=0;
Open(cum1==0)=0;
Close(cum1==0)=0;
Low(cum1==0)=0;
High(cum1==0)=0;

PriceActionProfile(minutesIndex,:).Volume=PriceActionProfile(minutesIndex,:).Volume+Volume;
PriceActionProfile(minutesIndex,:).Open=PriceActionProfile(minutesIndex,:).Open+Open;
PriceActionProfile(minutesIndex,:).Close=PriceActionProfile(minutesIndex,:).Close+Close;
PriceActionProfile(minutesIndex,:).Low=PriceActionProfile(minutesIndex,:).Low+Low;
PriceActionProfile(minutesIndex,:).High=PriceActionProfile(minutesIndex,:).High+High;

end
end

    catch
    end
    
end
end

PriceActionProfile.Volume=PriceActionProfile.Volume./DataCount;
PriceActionProfile.Open=PriceActionProfile.Open./DataCount;
PriceActionProfile.Close=PriceActionProfile.Close./DataCount;
PriceActionProfile.Low=PriceActionProfile.Low./DataCount;
PriceActionProfile.High=PriceActionProfile.High./DataCount;

vfilename=['Z:\My files\Project trading\traderdata\data_processed\priceactionprofile\' filefriendlysymbol(contract.FileSymbol) ' priceactionprofile.mat'];
save(vfilename,'PriceActionProfile');

    catch exception
     getReport(exception,'extended','hyperlinks','off') 
    
end

end


PriceActionProfile.Date=datetime('2020-06-01 09:30:00')+minutes((0:389)');

cndl5(PriceActionProfile);

min_=min(PriceActionProfile.Low);
max_=max(PriceActionProfile.High);

ylim([min_ max_]);
