apikey='9DA0ZYLF59IGMA6TDXEGKFXVEKAC3TWS';
periodType='day';
period=1;
frequencyType='minute';
frequency=1;
disabled=0;





symbol='BYND';
datetimes{1}='2020-06-29 10:36:00';
datetimes{2}='2020-06-29 15:54:00';

ndt=numel(datetimes);

for i=1:ndt
    disp(datetimes{i});
    dt=datetime(datetimes{i});
    
    date1=datestr(dt-minutes(15),'yyyy-mm-dd');
    date2=datestr(dt+days(1),'yyyy-mm-dd');
    
    % grab the minute data on the date 
    dd=datestr(datetime(datetimes{i}),'yyyy-mm-dd');
    filename=['Z:\My files\Project trading\traderdata\data\' filefriendlysymbol(symbol) ' minute ' dd '.mat'];
    if (exist(filename))
    load(filename);
    else
     [tm,~,~,~]=getMarketDataViaYahooByPeriod(symbol,date1,date2, '1m',[],[]); 
      
%         [tmfull,jmfull] = getMarketDataViaTDAByPeriod( symbol, periodType,date1,date2,frequencyType,frequency,apikey);
%    if (~isempty(tmfull))
%     success=0;
%      [tm,jm]=getMarketTimeData(tmfull);
%    end
    end
    
    ttm=table2timetable(tm);
    num2str(table2array(ttm(dt,:)))
    
end